/* example program dtlev85d                                                 */
/* illustrates blob-based uniformity computation                            */
/* three arguments are: 1) the gray level image filename,                   */
/* 2) the segmented image filename, and 3) the background value             */
/*     dtlev85a data/dice64.pgm data/dice64s.pgm 0                          */
/* uniformity of each non-background blob is computed and printed           */
/* all error checking left out for clarity                                  */

#include <dt.h>
#include <dtlev85.h>

static int n = 0;                     /* global stuff                       */
static unsigned long xsum, ysum;
static dtlev85_t lev85;

dt_rc_e
mycallback(
  dt_ctl_t *ctl,
  dtimage_adj_callback_arg_t *arg,
  dtxy_t x1,
  dtxy_t y1,
  dtxy_t x2,
  dtxy_t y2)
{
  int flag = arg->flag;
  dthist_freq_t * const h =           /* for quick access                   */
    lev85.hist->freq;
  int x, y;

  arg->flag = 0;                      /* clear flag for next blob           */

  if (flag & DTIMAGE_ADJ_FLAG_END)    /* finishing an old blob?             */
  {
    dtlev85_contribute(NULL, &lev85); /* contribute blob's histogram        */
    dtlev85_compute(NULL, &lev85);    /* compute blob's uniformity          */
    printf("  blob %4d: "             /* print out blob's uniformity        */
      " area %6ld, centroid (%lu,%lu),"
      " uniformity %0.5f",
      n++, lev85.Aa,
      xsum / lev85.Aa,
      ysum / lev85.Aa,
      lev85.u);

    if (!(flag &                      /* not also starting a new blob?      */
          DTIMAGE_ADJ_FLAG_BEG))
      return DT_RC_GOOD;
  }

  if (flag & DTIMAGE_ADJ_FLAG_BEG)    /* starting a new blob?               */
  {
    dtlev85_init(NULL, &lev85, 1,     /* reinit lev85 structure             */
      lev85.gray, lev85.hist);
    dthist_clear(ctl, lev85.hist);    /* clear histogram                    */
    xsum = 0;                         /* clear centroid accumulators        */
    ysum = 0;
  }

  for (y=y1; y<=y2; y++)
    for (x=x1; x<=x2; x++)
    {
      h[lev85.gray->row[y].b08[x]]++; /* histogram contribution             */
      xsum += x;                      /* centroid contribution              */
      ysum += y;
    }

  return DT_RC_GOOD;                  /* keep doing blobs                   */
}

void main(int argc, char *argv[])
{
  dtimage_t gray;
  dtimage_t segmented;
  double background;
  dthist_t hist;

  dtimage_import(NULL,                /* read and allocate gray image       */
    &gray, argv[1]);
  dtimage_import(NULL,                /* read and allocate segmented image  */
    &segmented, argv[2]);
  background = atol(argv[3]);         /* get background from command line   */

  dthist_alloc(NULL,                  /* space for histogram                */
    &hist, 256, 0, 256);              /* histogram bins referenced directly */
  dtlev85_init(NULL, &lev85, 1,       /* init global lev85 structure        */
    &gray, &hist);
  dtimage_adj(NULL,                   /* compute uniformity by blobs        */
    &segmented,
    0, 0, gray.xe, gray.ye,           /* use whole input image              */
    background,
    mycallback,                       /* call mycallback() for each blob    */
    NULL);                            /* mycallback() needs no arg          */
}
