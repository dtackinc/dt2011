/*..........................................................................
| TITLE
| Algorithm: dtlev85 Guide
| 
| ABSTRACT
| This is an implementation of a segmentation performance measuring algorithm.
| The algorithm is due to Levine and Nazif.
| It is described completely in [lev85].
| Input consists of two images.
| The first image is the original gray level image.
| The second image contains pixels whose values are labels which
| indicate membership in a connected region.
| One or more regions may be considered together as an area.
| For each area, the algorithm produces a single numeric uniformity measure.
| Uniformity values near 1.0 signify that the pixels within the regions of the area
| are similar in gray level.
| The algorithm is implemented as a C-callable library of routines.
| A simple main program provides command-line execution of the routines.
| The main program has an option for verifying the correctness
| of the implementation.
| The source code is modular and platform- and hardware-independent.
| Compilation instructions in the form of makefiles are provided for
| several platforms including Unix, DOS, Microsoft Windows and others. 
|
|!Overview
|_figure half, gray5.ps, Billiard Balls Gray Level
| 
|_figure half, seg5b.ps, Billiard Balls Naive Uniformity xxxx
|_figure half, seg5a.ps, Billiard Balls Better Uniformity xxxx
|
|.~What are the goals of the algorithm?~
| Given a gray level image and its segmentation,
| the algorithm attempts to provide a single number called the uniformity.
| The uniformity may be considered a measure
| of the goodness of the segmentation.
| 
|.~How would you use the algorithm?~
| First you produce a segmented image by any desired means.
|_aside Use your favorite segmentation.
| Binary thresholding is one of the many possibilities.
| Then you simply feed the original gray level image along with
| the segmented image into the algorithm.
| You may use the resulting uniformity as input to a decision process.
| For example, if the uniformity is not high enough,
| you may want to rerun the segmentation with modified parameters.
|
|.~What does the output look like?~
| The output is normally just a single number between 0.0 and 1.0
| for each designated area.
| However, printed numbers can be fairly boring.
|_aside Output a color image for fun.
| Therefore, the sample program can optionally use the numbers
| as color indices in an output image.
| The visual feedback obtained in this way may actually be useful.
| 
|.~What should you be aware of?~
| This algorithm does not perform segmentation.
| Rather, it requires a segmented image as input.
|
| Careful blob conditioning may be required.  
| For example, the uniformity measure is normalized, in part, 
| by the range of pixel values.
| A single pixel with an extreme gray value may artificially skew
| the uniformity value toward higher a value.
|
| The uniformity measure was designed by its creators in conjunction
| with several other measures.
| There is no discussion of its suitability when used by itself.
| You must take care to clearly understand the algorithm before
| placing any importance on its outcome.
| 
|.~What is the interface to the implementation?~
| The implementation has both a run-ready main program 
| and a C-callable library.
|_aside The library does the work.
| The main program uses the library to do all its tasks.
| It has a number of command-line options.
|_aside The main program is mainly a demo.
| It will read a pair input images and print out the uniformity numbers.
| Optionally, it will make an output image where each blob is
| colored according to the uniformity value of its region.
| 
|.~What inputs do the C-callable library routines require?~
| You must provide a pair of data structures describing two input images.
|_aside You provide the input images.
| For more control over the algorithm,
| you may want to provide callback routines to handle
| the uniformity numbers on a label-by label or blob-by-blob basis.
| 
|.~What do the library routines output?~
| The easiest routines return a single uniformity number or
| array of numbers.
| However, if you provide a callback routine, you will have complete
| control over what is output.
| 
|.~Does the implementation test itself?~
|dtinclude(testdsc1.dx)
| 
|.~Can you modify it?~
|dtinclude(srcdist1.dx)
| 
|.~What documentation exists for it?~
|dtinclude(doclist1.dx)
| 
|.~How do you install it?~
| Installation requires the prior installation of the
|_aside No fee for base library licenses.
| Dtack Imaging Software base libraries.
| All installation may be done in a single directory by a simple script.
| An accompanying document entitled "Algorithm dtlev85: Installation"
| gives detailed instructions for each major operating system.
| 
| To use the software after installation, only the following are required:
|_aside Actual names may vary slightly depending on operating system.
| :dtlev85.h:		header file
| :dtlev85.lib: 	algorithm library
| :dthigh.lib:	 	high level base library
| :dtlow.lib:	 	low level base library
| :dtlev85:			main program executable 
|					(not required if you write your own program)
|
|!About the Algorithm
| Measures of the performance of a segmentation process
| are required as feedback if the process is to iteratively
| modify its parameters in order to improve its results.
| 
| Points to make:
| 0. segmentation measurement is hard [fu81]
| 1. most articles don't measure goodness, they just show pictures
| 2. when they do measure goodness, they compare it to human
| 3. some automatic quantitative work has been done, but not much
| 
| [wes78b] proposes two other methods for measuring the goodness
| of a thresholded image.
| One is based on the busyness and is computed using a co-occurrence matrix
| technique.  
| The other is called a discrepancy measure and reflects the
| degree of classification error probably assuming a gray level distribution.
| 
| [yas77] proposes two error measures for comparison and evaluation
| of a machine segmentation with a human segmentation of the same scene.
|
| Many researchers rely on a human segmentation as a ground truth
| to which to compare the performance of a new computer-generated segmentation.
| [yam80]
| 
| in presenting the results of their segmentation algorithms,
| many researchers simply display their results for visual,
| subjective evaluation by the reader.
| [wes74],
| It is commonly agreed that a good segmentation process will
|_aside Computer's opinion should agree with human's.
| simulate a human's judgment when observing the same segmentation.
| Much literature is devoted to techniques involving the use
| of a human-produced segmentation as the ideal segmentation to
| which any machine-produced segmentation is compared.
| However, to be used in real-time applications,
| the goodness measures must be automatic and made without human intervention.
|
| [lev85] discusses four automatic segmentation measures
|_aside The source article.
| which attempt to meet both criteria:
| they simulate a human's judgment but do it in an automatic manner.
| They were developed to serve as the feedback mechanisms
| to guide improvement in a
| complex rule based low level image segmentation system.
| The measures include region uniformity, region contrast,
| line contrast, and texture measures.
| 
| This implementation covers the region uniformity measure only.
| 
| The uniformity of a region varies inversely with the variance
| of the feature being measured.
| This means that if a region contains only pixels whose values
| are close to the average value, it will have a uniformity close to 1.0.
| In the limit, a region of constant value will have a uniformity of
| exactly 1.0.
| 
| The size of a region linearly affects how much that region's
|_aside Bigger regions carry more weight.
| uniformity contributes to the uniformity of the area.
| The uniformity measure is weighted such that its range is between
| 0.0 and 1.0.
| The justification is that uniformity can be thought of as
| being more noticeable in large regions.
|
| The uniformity measure is designed to be efficiently computable
| in a dynamic situation where regions are frequently being split and merged.
| 
| Other than the authors' previous work [lev82] and [lev84],
| all other references to the literature are related to
| line-based measures as opposed to region-based measures.
| 
|.Terminology
| area		    Any group of pixels on which uniformity is to be computed.
|			    Typically an area consists of multiple regions.
| blob		    The term blob is used interchangeably with region in this
|			    documentation.
| feature		Value of the pixels in the "gray level" image.
|				Note that the pixels need not necessarily represent
|				a visual brightness response,  but could be anything
|				which can be encoded as a single number for each pixel.
| gray level	Value of pixels in the original image.
|				This may be a visual brightness or any other numeric quantity
|				associated with a point position in the geometric plane.
| label			The value of a pixel in the segmented image.
|				This is not normally a brightness value, but rather
|				a value which indicates the pixel's membership in a region.
| region		Any group of connected pixels.  Connectivity is defined by
|				4-connectedness of the pixels having the same label value
|				in the segmented image.
|				The term region is used interchangeably with blob in this
|				documentation.
| uniformity	Number between 0.0 and 1.0 given by equation 7 of [lev85].
| 
| [fig:draw6.ps] illustrates the concept of regions and areas.
| Ignoring the background and based strictly on pixel connectivity,
| there are six regions in the picture.
| Three of the regions are rectangular and three are circular.
|
|_figure half, draw6.ps, Six simple regions
|
| There are many ways in which these regions may be combined into areas,
| among them:
| 1.	each region as its own area
| 2.	all square regions in one area and all circular in another
| 3.	all small regions in one area and all large in another
| 4.	all dark regions in one area and all light in another
| 5.	all regions near the top in one area and all near the bottom in another
| There are many other possiblies.
| Remember, a uniformity number is computed on an area basis.
| The flexibility to allow multiple, possibly dispersed, regions to contribute to
| a uniformity measure is one of the features of this implementation.
| 
|.Basic Procedure
| The implementation provides two convenience functions for
| collecting pixels into regions and regions into areas
| on which uniformity is computed.
| These are dtlev85_total() and dtlev85_label().
| Both the functions ultimately use the same basic procedure.
| While the convenience functions may be suitable for simple applications,
| more complex problems will require you to make direct use of the
| basic procedure.
| The basic procedure for computing uniformity with this implementation
| is as follows:
| 1.	initialize structure using dtlev85_init()
| 2.	build a histogram of one region
| 3.	accumulate the region, completely characterized by its histogram,
|		into the area using dtlev85_contribute()
| 4.	repeat steps 2 and 3 for all regions in the area
| 5.	compute final uniformity on the area using dtlev85_compute()
|
| Although the steps to computing uniformity are simple,
|_aside Your application has unique needs.
| each application will have different criteria for selecting
| regions which contribute to be area whose uniformity is of interest.
| 
|!Implementation Interface
| The  programs and subroutines in this implementation
| work together to produce
| uniformity measures for selectable image areas.
|
| :dtlev85:				main program parses command line arguments
|							and calls the functions
| :dtlev85a:			sample program showing total uniformity
| :dtlev85b:			sample program showing label-by-label uniformity
| :dtlev85c:			sample program showing basic uniformity technique
| :dtlev85d:			sample program showing blob-by-blob uniformity
| dtlev85_total()		produces total uniformity for an area which consists
|							of all non-background pixels
| dtlev85_label()		produces a separate uniformity for each area
|							distinguished by a unique label in the segmented
|							image
| dtlev85_init()		initializes an array of dtlev85 structures
| dtlev85_contribute()	adds a region's histogram to the uniformity
|							being accumulated for an area
| dtlev85_compute()		computes the uniformity measure for an area 
| dtlev85_combine()		combine two areas
|
|dtinclude(image_t1.dx)
| 
| The principal data structure used in computing and returning
| the uniformity includes the following members:
| 
|:typedef struct {
|_aside Data structure for this algorithm.
|:  double u;							// computed uniformity 		  
|:  long n;								// number of regions		  
|:  double fmax, fmin;					// max data range found		  
|:  long Aa;							// total area accumulator	  
|:} dtlev85_t;
| 
|!Implementation Notes
| This section describes assumptions and deviations of the
| implementation from the original article.
|
| This implementation follows the algorithm as described in [lev85]
| Section III as closely as possible.
| The ordering of computation is altered to support various
| means of assembling regions into areas.
|
| The segmented images may be any data type from single-bit
| to double precision.
| It is important to allow data values which can hold more than
| 256 labels since many segmentation processes produce
| many more blobs than this.
| The ability to handle any data type is provided by the
| underlying connected components engine in the
| Dtack Imaging Software Base Library.
| 
| While the segmented images may be any data type,
| the implementation only accepts unsigned 8-bit gray level images.
| This is judged acceptable since the uniformity is inherently unitless.
| Constraining the input pixels to be in the range 0 to 255
| means a general loss of significant digits in the resulting number.
| It is unlikely that a real-world application will be
| seriously affected by the loss of accuracy.
| On the positive side this trade-off greatly reduces code complexity,
| increases robustness, and decreases execution time,
| and diminishes storage requirements.
| 
| The Dtack Base Library provides several useful utility functions
| which make it easy to scale-convert any higher precision image
| into the full dynamic range of the
| unsigned 8-bit image required by this algorithm.
| 
| The implementation uses the concept of using a histogram
|_aside Histogram is a convenient vehicle.
| of a region for part of a region
| as input to the uniformity computation.
| This concept was not part of the original article.
| It has been introduced by the implementation as a convenient
| means of summarizing the gray levels of a section of image.
| 
| This implementation uses the concept of a background pixel value.
|_aside Background pixels don't count.
| This value, when occurring in the segmented image,
| is never associated with a region.
| Thus background pixels are never considered part of any area
| for which uniformity is computed.
| The value to be used for the background is selectable.
| If you wish to compute the uniformity of all pixels in an image,
| simply select a background value which does not occur in the
| segmented image.
| This feature (or limitation, if you will) is
| due to the connectivity engine used by this implementation,
| and not in any way related to be original algorithm formulation.
|
|!Application Examples
| This section gives practical examples of the use of this algorithm.
|
|.Total Uniformity
| In some applications the segmented image will naturally consist
| of only two distinguishable areas.
| Such an image is often represented as
| a bivalued image where one value represents the background
| and the other the object.
| A binary threshold operation produces this kind of image.
| Similarly for a multi-valued image, one value (perhaps zero)
| represents the background,
| and all other values represent the object.
| 
| For such applications the simplest solution is to use
| the convenience function dtlev85_total().
| This function does not select specific regions.
| In other words, all non-background regions are considered
| part of a single area on which a single uniformity is calculated.
| 
| For example, consider [fig:gray5-2.ps].
| Using the binary segmentation illustrated by [fig:seg5b-2.ps],
|_aside Just the objects.
| the total uniformity for all the balls is xxxx.
| You get list by specifying ~background~=255
| which causes all white areas to be ignored.
| 
|_figure half, gray5-2.ps, Billiard Balls Gray Level
| 
|_figure half, seg5b-2.ps, Billiard Balls Naive Binary Segmentation
|_figure half, seg5a-2.ps, Billiard Balls Better Binary Segmentation
| 
| If, however, you were interested in the uniformity of 
| all parts of the picture #except# the balls,
|_aside Just the background.
| you would specify ~background~=0.
| This would cause the black blobs to be ignored, 
| getting a uniformity of xxxx.
| 
| It is also possible to compute the uniformity of the entire picture,
|_aside Objects and background all together.
| including both balls and non-ball area.
| Simply specify ~background~=1.
| Since the label value 1 does not occur in the segmented image,
| no parts of the image are ignored,
| and you get a uniformity of xxxx.
| 
| Using the same background values as above,
| except this time with the binary [fig:seg5a-2.ps] as the segmentation,
| you get:
| background 255	uniformity of balls xxxx
| background 0		uniformity of non-ball parts of the image xxxx
| background 1		uniformity of entire picture xxxx
| 
| As expected from the better segmentation in [fig:seg5a-2.ps],
| the uniformity numbers are higher
| than those for [fig:seg5b-2.ps].
| 
| Note that dtlev85_total() cannot give the uniformity for just
| one of the balls using the segmentation in either [fig:seg5b-2.ps]
| or [fig:seg5a-2.ps].
| For that, you will need dtlev85_label() as described below.
|
|.Uniformity Based on Labels
| Suppose you have an application where your segmented
| image has more than two regions in it.
| Consider [fig:gray5-3.ps] and its corresponding segmentation
| [fig:seg5c.ps].
| The segmentation is not a bivalued image.
| It has four different pixel values (i.e. labels):
| the background plus
| the three blobs marked by the numerals.
| 
|_figure half, gray5-3.ps, Billiard Balls Gray Level
| 
|_figure half, seg5d.ps, Billiard Balls Naive Multi-labeled Segmentation
|_figure half, seg5c.ps, Billiard Balls Better Multi-labeled Segmentation
|_aside The numerals are not part of the images.
| 
| To compute a uniformity for each labeled region separately,
| a suitable function is dtlev85_label().
| For [fig:seg5d.ps], the regions produce uniformity numbers:
| label 1	uniformity xxxx
| label 2	uniformity xxxx
| label 3	uniformity xxxx
| 
| Contrast the uniformity numbers produced from the better segmentation
| in [fig:seg5c.ps]:
| label 1	uniformity xxxx
| label 2	uniformity xxxx
| label 3	uniformity xxxx
| 
| It is interesting to note that the squarish
| segmentation (first table)
| actually produces a higher uniformity number for ball 3
| than the roundish segmentation (second table).
| This is probably due to the blurry nature of this ball.
| 
| The function dtlev85_label() can group several regions
| in the same area for uniformity purposes.
| This is illustrated by the segmentation [fig:seg5c.ps].
| Although all three balls are separate regions,
| the two lighter balls have been given the same label, label 1.
| Here are the uniformity numbers:
| label 1	uniformity xxxx, nregions 2
| label 2	uniformity xxxx, nregions 1
| 
| Note that label 2 under this segmentation corresponds exactly
| to label 3 of [fig:seg5c.ps]
| and therefore has exactly the same uniformity.
|
|.Uniformity Based on Blobs
| The dtlev85_label() function just discussed computes uniformity
| numbers based on distinct labels found in the segmented image.
| But what if you need the uniformity of each blob in your image,
| yet your segmented image does not assign a different label to
| each one?
| Or what if you need to select only certain blobs
| at run time,
| say based on blob size?
| You can program a solution to these applications by writing a 
| simple callback routine.
|_aside You have to write your own function.
| The callback routine will receive all the pixels for one blob
| before receiving any pixels for the next blob.
| from within the callback routine,
| You may selectively compute the uniformity
| on only those blobs meeting your criteria.
| 
| The callback routine should make use of dtlev85_init(),
| dtlev85_contribute(), and dtlev85_compute() to produce uniformity
| measures on each blob as desired.
| Example :lev85d.c: in the next section illustrates this.
|
| EXAMPLE lev85d.c
|:// example program dtlev85d
|:// illustrates blob-based uniformity computation
|:// three arguments are: 1) the gray level image filename, 
|:// 2) the segmented image filename, and 3) the background value
|://     dtlev85a data/dice64.pgm data/dice64s.pgm 0
|:// uniformity of each non-background blob is computed and printed
|:// all error checking left out for clarity
|:
|:#include <dt.h>
|:#include <dtlev85.h>
|:
|:static int n = 0;						// global stuff
|:static unsigned long xsum, ysum;
|:static dtlev85_t lev85;
|:
|:dt_rc_e
|_aside You should write a function like this.
|:mycallback(
|:  dt_ctl_t *ctl,
|:  dtimage_adj_callback_arg_t *arg,
|:  dtxy_t x1,
|:  dtxy_t y1,
|:  dtxy_t x2,
|:  dtxy_t y2)
|:{
|:  int flag = arg->flag;
|:  dthist_freq_t * const h =			// for quick access	
|:    lev85.hist->freq;
|:  int x, y;
|:
|:  arg->flag = 0;						// clear flag for next blob	
|:
|:  if (flag & DTIMAGE_ADJ_FLAG_END)	// finishing an old blob?			
|_aside Connected components tells us blob is finished.
|:  {
|:	  dtlev85_contribute(NULL, &lev85);	// contribute blob's histogram
|:    dtlev85_compute(NULL, &lev85);	// compute blob's uniformity		
|:    printf("  blob %4d: "				// print out blob's uniformity		
|:      " area %6ld, centroid (%lu,%lu),"
|:      " uniformity %0.5f",
|:	    n++, lev85.Aa,
|:      xsum / lev85.Aa,
|:      ysum / lev85.Aa,
|:      lev85.u);
|:
|:    if (!(flag & 						// not also starting a new blob?	
|:          DTIMAGE_ADJ_FLAG_BEG))
|:      return DT_RC_GOOD;
|:  }
|:
|:  if (flag & DTIMAGE_ADJ_FLAG_BEG)	// starting a new blob?				
|:  {
|:    dtlev85_init(NULL, &lev85, 1,		// reinit lev85 structure			
|:      lev85.gray, lev85.hist);
|:    dthist_clear(ctl, lev85.hist);	// clear histogram					
|:	  xsum = 0;							// clear centroid accumulators		
|:    ysum = 0;
|:  }
|:
|:  for (y=y1; y<=y2; y++)
|_aside Add this little piece of blob to the histogram.
|:    for (x=x1; x<=x2; x++)
|:    {
|:	    h[lev85.gray->row[y].b08[x]]++;	// histogram contribution			
|:	    xsum += x;						// centroid contribution			
|:      ysum += y;
|:    }
|:    
|:  return DT_RC_GOOD;					// keep doing blobs				    
|:}
|:
|:void main(int argc, char *argv[])
|:{
|:  dtimage_t gray;
|:  dtimage_t segmented;
|:  double background;
|:  dthist_t hist;
|:
|:  dtimage_import(NULL,		 		// read and allocate gray image
|_aside Read the two input images.
|:    &gray, argv[1]);
|:  dtimage_import(NULL,		 		// read and allocate segmented image
|:    &segmented, argv[2]);
|:  background = atol(argv[3]);			// get background from command line
|:
|:  dthist_alloc(NULL,					// space for histogram
|:    &hist, 256, 0, 256);				// histogram bins referenced directly
|:  dtlev85_init(NULL, &lev85, 1,		// init global lev85 structure
|:    &gray, &hist);
|:  dtimage_adj(NULL,       			// compute uniformity by blobs
|_aside Do connected components analysis.
|:    &segmented,
|:    0, 0, gray.xe, gray.ye,			// use whole input image 
|:    background, 
|:    mycallback, 						// call mycallback() for each blob
|:    NULL);							// mycallback() needs no arg
|:}
| 
|.Example application: Dominoes image
| This example tries to show various ways of getting
| uniformity numbers for different parts of the image.
| [fig:gray2.ps] has been segmented into the 3-valued image [fig:seg2b.ps].
| 
|_figure half, gray2.ps, Dominoes Gray Level
|_figure half, seg2b.ps, Dominoes 3-Valued Segmentation
| 
| The labels given to the segmented image correspond roughly to:
| xxx	dark parts of domino bodies
| xxx	shadow areas around domino bodies
| xxx	background and dots
| 
| Here are some uniformity numbers:
| whole image			xxxx dtlev85_total() with ~background~=0
| domino bodies			xxxx dtlev85_label()
| shadows				xxxx dtlev85_label()
| background and dots	xxxx dtlev85_label()
| bodies and shadows	xxxx custom callback selecting only labels xxx and xxx
| just dots				xxxx custom callback selecting only small bright blobs
| 
|.Example application: Letters image
| This example attempts to give a feel for
| the visual correlation between the original gray level image
| [fig:gray3.ps]
| and total uniformity under various segmentations.
| 
|_figure half, gray3.ps, Hazy Letters Gray Level
| 
|_figure half, seg3a.ps, Hazy Letters Binary Threshold 150
|_figure half, seg3b.ps, Hazy Letters Binary Threshold 180
| 
| The total uniformity as been calculated using ~background~=1.
| Since the value 1 does not occur in any of these segmentations,
| we have effectively computed the uniformity
| of the entire image in each case.
| [fig:seg3a.ps]	uniformity xxxx, nregions xxxx
| [fig:seg3b.ps]	uniformity xxxx, nregions xxxx
| 
|.Example application: Synthetic image
| This example shows the effects of quantitative contamination
| when a segmentation does not perfectly match the original image.
| 
| [fig:gray4a.ps] is a synthetic gray level image.
| The vertical line represents the border between
| the two halves of the arbitrary segmentation in [fig:seg4a.ps].
| 
|_figure half, gray4a.ps, Synthetic Gray Level Image
|_figure half, seg4a.ps, Synthetic Gray Level Aribrary Segmentation
| 
| The uniformity numbers are:
| total	uniformity xxxx
| area1	uniformity xxxx
| area2	uniformity xxxx
| 
| Due contamination of each gray level into the other's segment,
| neither has a perfect uniformity.
| Since the intrusion of the area1 side into the area2 side
| is of greater geometric extent,
| the area2 side as a lower uniformity.
| 
| [fig:gray4b.ps] is the same synthetic gray level image,
| however the vertical line represents a slightly different
| segmentation border.
| The segmentation is shown in [fig:seg4b.ps].
| 
|_figure half, gray4b.ps, Synthetic Gray Level Image Again
|_figure half, seg4b.ps, Alternate Synthetic Gray Level Aribrary Segmentation
| 
| The uniformity numbers are:
| total uniformity xxxx
| area1	uniformity 1.0
| area2	uniformity xxxx
| 
| This time the area1 side of the gray level image
| has a perfect uniformity because no area2 pixels
| creep into it under the segmentation.
| However, many area1 pixels contaminate the area2 side,
| giving it an even worse segmentation than for [fig:gray4a.ps].
| 
| END
 *..........................................................................*/
