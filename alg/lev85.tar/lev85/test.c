/*..........................................................................
| NAME
| Introduction - intro
| 
| DESCRIPTION
| As yet undocumented.
| 
| RETURN VALUES
| Function return value will be DT_RC_GOOD on success.  
| Any other return value indicates failure or noncompletion.
| When DT_RC_GOOD is not returned, any other return values may not be valid.
| 
| ERRORS
| As yet undocumented.
| 
| END
 *..........................................................................*/


#include <dt.h>

DT_RCSID("lev85 $RCSfile: test.c,v $ $Revision: 1.7 $");

#include <dtlev85.h>
#include <dtmem.h>
#include <dtstr.h>
#include <dt1d.h>

#define USAGE "[-Dnnnn]"

#define LABEL_ARG_MAX (10)
typedef struct {
  int count;
  double v[LABEL_ARG_MAX];
  double u[LABEL_ARG_MAX];
  long   n[LABEL_ARG_MAX];
} label_arg_t;

/*..........................................................................*/

int
dtlev85_test_all(
  dtparam_t *param,
  int *assert_fail)
{
  DT_F("dtlev85_test");
  dt_ctl_t *ctl = &param->ctl;
  int i;

    DT_Q(dtlev85_test1,(param, 
      assert_fail));

#ifdef NONO
    DT_Q(dtlev85_test2,(param,
      assert_fail));

    DT_Q(dtlev85_test3,(param,
      assert_fail));

    DT_Q(dtlev85_test4,(param,
      assert_fail));

    DT_Q(dtlev85_test5,(param,
      assert_fail));

    DT_Q(dtlev85_test6,(param,
      assert_fail));
#endif

  return DT_RC_GOOD;
}

/*..........................................................................*/
static 
dt_rc_e
dtlev85_test_make(
  dt_ctl_t *ctl,
  dtimage_t *image,
  unsigned int ncols,
  unsigned int nrows,
  dt_ntype_e image_ntype,
  void *data,
  dt_ntype_e data_ntype)
{
  static char *F = "dtlev85_test_make";
  dtxy_t y;
  unsigned int rowsize = (unsigned int)
    (ncols * dt_ntype_sizeof[data_ntype]);

  DT_Q(dtimage_create,(ctl,				/* make image to hold given data    */
    image, ncols, nrows, 
    image_ntype));
 
  for (y=0; y<nrows; y++)				/* copy given data row by row		*/
  {
    void *p;
    DTIMAGE_MAPROW(ctl, image, y, &p);
	DT_Q(dt1d_cast,(ctl,
      data, ncols, data_ntype,
      p, ncols, image_ntype));
    DTIMAGE_PUTROW(ctl, image, y);
    data = (char *)data + rowsize;
  }

  return DT_RC_GOOD;
}

/*..........................................................................*/

dt_rc_e
dtlev85_test_total(
  dtparam_t *param,
  dt_ntype_b08_t *gray_data,
  dt_ntype_e gray_ntype,
  dt_ntype_b08_t *segmented_data,
  dt_ntype_e segmented_ntype,
  dtxy_t ncols,
  dtxy_t nrows,
  double background,
  double expect_uniformity,
  long   expect_nregions,
  int *assert_fail,
  char *f)
{
  static char *F = "dtlev85_test_total";
  dt_ctl_t *ctl = &param->ctl;
  dtimage_t gray;
  dtimage_t segmented;
  dtlev85_t lev85;
  dt_rc_e rc;

  segmented.xe = 0;
  gray.xe = 0;

  DT_C(dtlev85_test_make,(ctl,			/* make gray image				    */
    &gray, ncols, nrows, 
    gray_ntype,
    gray_data, DT_NTYPE_B08));

  DT_C(dtlev85_test_make,(ctl,			/* make segmented image			    */
    &segmented, ncols, nrows, 
    segmented_ntype,
    segmented_data, DT_NTYPE_B08));

  DT_C(dtlev85_total,(param,			/* do algorithm						*/
    &gray, &segmented, background,
    &lev85));

  *assert_fail += DT_RC_GOOD != dt_assert(ctl,
    expect_uniformity == lev85.u &&
    expect_nregions == lev85.n,
    f, 
    "%-3s %-3s total uniformity %0.5f (%0.5f),"
    " nregions %ld (%ld)",
    dt_ntype_string[gray_ntype],
    dt_ntype_string[segmented_ntype],
    lev85.u, expect_uniformity,
    lev85.n, expect_nregions);

cleanup:
  if (segmented.xe != 0)
    DT_I(dtimage_free,(ctl,
      &segmented));
  if (gray.xe != 0)
    DT_I(dtimage_free,(ctl,
      &gray));
  return rc;
}

/*..........................................................................
 *..........................................................................*/

dt_rc_e
dtlev85_test_label_callback(	
  dt_ctl_t *ctl,						/* environment control structure 	*/
  void *callback_arg,					/* passed through from application 	*/
  double label,							/* input current label value 		*/
  dtlev85_t *lev85)						/* input computed uniformity 		*/
{
  label_arg_t *arg = 
    (label_arg_t *)callback_arg;
  if (arg->count < LABEL_ARG_MAX)
  {
    arg->v[arg->count] = label;
    arg->u[arg->count] = lev85->u;
    arg->n[arg->count] = lev85->n;
  }
  arg->count++;
  return DT_RC_GOOD;
}

/*..........................................................................*/

dt_rc_e
dtlev85_test_label(
  dtparam_t *param,
  dt_ntype_b08_t *gray_data,
  dt_ntype_e gray_ntype,
  dt_ntype_b08_t *segmented_data,
  dt_ntype_e segmented_ntype,
  dtxy_t ncols,
  dtxy_t nrows,
  double background,
  int    nlabels,
  double *expect_value,
  double *expect_uniformity,
  long   *expect_nregions,
  int *assert_fail,
  char *f)
{
  static char *F = "dtlev85_test_label";
  dt_ctl_t *ctl = &param->ctl;
  dtimage_t gray;
  dtimage_t segmented;
  label_arg_t label_arg;
  int i;
  dt_rc_e rc;

  segmented.xe = 0;
  gray.xe = 0;

  DT_C(dtlev85_test_make,(ctl,			/* make gray image				    */
    &gray, ncols, nrows, 
    gray_ntype,
    gray_data, DT_NTYPE_B08));

  DT_C(dtlev85_test_make,(ctl,			/* make segmented image			    */
    &segmented, ncols, nrows, 
    segmented_ntype,
    segmented_data, DT_NTYPE_B08));

  memset(&label_arg, 0, 
    sizeof(label_arg));
  
  DT_C(dtlev85_label,(param,			/* do algorithm						*/
    &gray, &segmented, background,
    dtlev85_test_label_callback, 
    &label_arg));

  for (i=0; i<DT_MIN(nlabels, label_arg.count); i++)
  {
    *assert_fail += DT_RC_GOOD != dt_assert(ctl,
      expect_value[i] == label_arg.v[i] &&
      expect_uniformity[i] == label_arg.u[i] &&
      expect_nregions[i] == label_arg.n[i],
      f, 
      "%-3s %-3s label[%d] %g (%g),"
      " uniformity %0.5f (%0.5f),"
      " nregions %ld (%ld)",
      dt_ntype_string[gray_ntype],
      dt_ntype_string[segmented_ntype],
      i,
      label_arg.v[i], expect_value[i],
      label_arg.u[i], expect_uniformity[i],
      label_arg.n[i], expect_nregions[i]);
  }

  *assert_fail += DT_RC_GOOD != dt_assert(ctl,
    nlabels == label_arg.count,
    f, "%-3s %-3s label count %d (%d)",
    dt_ntype_string[gray_ntype],
    dt_ntype_string[segmented_ntype],
    label_arg.count, nlabels);

cleanup:
  if (segmented.xe != 0)
    DT_I(dtimage_free,(ctl,
      &segmented));
  if (gray.xe != 0)
    DT_I(dtimage_free,(ctl,
      &gray));
  return rc;
}

/*..........................................................................*/

dt_rc_e
dtlev85_test1(
  dtparam_t *param,
  int *assert_fail)
{
  DT_F("dtlev85_test1");
  dt_ctl_t *ctl = &param->ctl;

#define NCOLS 16
#define NROWS 16
  static dt_ntype_b08_t gray_data[NCOLS*NROWS] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
    0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
    0,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,
    0,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
  };
  static dt_ntype_b08_t segmented_data[NCOLS*NROWS] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
    0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
    0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
    0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
  };

  int nlabels = 2;
  double label_value[] = {0, 1};
  double label_uniformity[] = {1.000000, 0.500000};
  long   label_nregions[] = {1, 2};

#define TOTAL(GRAY_NTYPE, SEGMENTED_NTYPE, BACKGROUND, UNIFORMITY, NREGIONS) \
  DT_Q(dtlev85_test_total,(param, \
    gray_data, \
    GRAY_NTYPE, \
    segmented_data, \
    SEGMENTED_NTYPE, \
    NCOLS, NROWS, \
    BACKGROUND, \
    UNIFORMITY, \
    NREGIONS, \
    assert_fail, F));

#define LABEL(GRAY_NTYPE, SEGMENTED_NTYPE) \
  DT_Q(dtlev85_test_label,(param, \
    gray_data, \
    GRAY_NTYPE, \
    segmented_data, \
    SEGMENTED_NTYPE, \
    NCOLS, NROWS, \
    9, \
    nlabels, \
    label_value, \
    label_uniformity, \
    label_nregions, \
    assert_fail, F));

  TOTAL(DT_NTYPE_F2,  DT_NTYPE_F2,  9.0, 0.984375, 3);

  TOTAL(DT_NTYPE_B08, DT_NTYPE_B08, 1.0, 1.000000, 1);
  TOTAL(DT_NTYPE_B08, DT_NTYPE_B08, 0.0, 0.500000, 2);
  TOTAL(DT_NTYPE_B08, DT_NTYPE_B08, 9.0, 0.984375, 3);

  TOTAL(DT_NTYPE_B08, DT_NTYPE_F2 , 9.0, 0.984375, 3);
  
  LABEL(DT_NTYPE_B08, DT_NTYPE_B08);

#undef NCOLS
#undef NROWS
    
  return DT_RC_GOOD;
}
#ifdef NONO
/*..........................................................................*/

dt_rc_e
dtlev85_test2(
  dtparam_t *param,
  int *assert_fail)
{
  DT_F("dtlev85_test2");
  dt_ctl_t *ctl = &param->ctl;

#define NCOLS 16
#define NROWS 16
  static dt_ntype_b08_t gray_data[NCOLS*NROWS] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
    0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
    0,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,
    0,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
  };
  static dt_ntype_b08_t segmented_data[NCOLS*NROWS] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,1,2,3,4,0,0,0,0,0,0,0,0,0,0,0,
    0,1,2,3,4,0,0,0,0,0,0,0,0,0,0,0,
    0,1,2,3,4,0,0,0,0,0,0,0,0,0,0,0,
    0,1,2,3,4,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,1,1,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,2,2,0,0,0,0,0,0,0,
    0,0,0,0,0,3,3,3,3,0,0,0,0,0,0,0,
    0,0,0,0,0,4,4,4,4,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
  };

  DT_Q(dtlev85_test,(param,			/* make images					    */
    &segmented_data[0],
    &gray_data[0],
    NCOLS, NROWS, 
    0.0,								/* background value				    */
    1.0,      1,						/* background results			    */
    0.5,      8,						/* foreground result			    */
    0.984375, 9,						/* combined						    */
    assert_fail, F));

#undef NCOLS
#undef NROWS
    
  return DT_RC_GOOD;
}
/*..........................................................................*/

dt_rc_e
dtlev85_test3(
  dtparam_t *param,
  int *assert_fail)
{
  DT_F("dtlev85_test3");
  dt_ctl_t *ctl = &param->ctl;

#define NCOLS 16
#define NROWS 16
  static dt_ntype_b08_t gray_data[NCOLS*NROWS] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
    0,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,
    0,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,
    0,2,2,2,2,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,2,2,1,1,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
  };
  static dt_ntype_b08_t segmented_data[NCOLS*NROWS] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
  };

  DT_Q(dtlev85_test,(param,			/* make images					    */
    &segmented_data[0],
    &gray_data[0],
    NCOLS, NROWS, 
    0.0,								/* background value				    */
    0.861328125, 1,						/* background results			    */
    0.0,         0,						/* foreground result			    */
    0.861328125, 1,						/* combined						    */
    assert_fail, F));

#undef NCOLS
#undef NROWS
    
  return DT_RC_GOOD;
}
/*..........................................................................*/

dt_rc_e
dtlev85_test4(
  dtparam_t *param,
  int *assert_fail)
{
  DT_F("dtlev85_test4");
  dt_ctl_t *ctl = &param->ctl;

#define NCOLS 16
#define NROWS 16
  static dt_ntype_b08_t gray_data[NCOLS*NROWS] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,
    0,4,4,4,4,0,0,0,0,0,0,0,0,0,0,0,
    0,8,8,8,8,8,8,0,0,0,0,0,0,0,0,0,
    0,8,8,8,8,8,8,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,8,8,8,4,4,0,0,0,0,0,0,0,
    0,0,0,0,8,8,8,4,4,0,0,0,0,0,0,0,
    0,0,0,0,8,8,8,4,4,0,0,0,0,0,0,0,
    0,0,0,0,8,8,8,4,4,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
  };
  static dt_ntype_b08_t segmented_data[NCOLS*NROWS] = {
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
  };

  DT_Q(dtlev85_test,(param,			/* make images					    */
    &segmented_data[0],
    &gray_data[0],
    NCOLS, NROWS, 
    1.0,								/* background value				    */
    0.0,    0,							/* background results			    */
    0.8125, 1,							/* foreground					    */
    0.8125, 1,							/* combined						    */
    assert_fail, F));

#undef NCOLS
#undef NROWS
    
  return DT_RC_GOOD;
}
/*..........................................................................*
 * worst case variance, all regions contain fmax and fmin
 *..........................................................................*/

dt_rc_e
dtlev85_test5(
  dtparam_t *param,
  int *assert_fail)
{
  DT_F("dtlev85_test5");
  dt_ctl_t *ctl = &param->ctl;

#define NCOLS 16
#define NROWS 16
  static dt_ntype_b08_t gray_data[NCOLS*NROWS] = {
    3,3,7,7,3,3,7,7,3,3,7,7,3,3,7,7,
    3,3,7,7,3,3,7,7,3,3,7,7,3,3,7,7,
    7,7,3,3,7,7,3,3,7,7,3,3,7,7,3,3,
    7,7,3,3,7,7,3,3,7,7,3,3,7,7,3,3,
    3,3,7,7,3,3,7,7,3,3,7,7,3,3,7,7,
    3,3,7,7,3,3,7,7,3,3,7,7,3,3,7,7,
    7,7,3,3,7,7,3,3,7,7,3,3,7,7,3,3,
    7,7,3,3,7,7,3,3,7,7,3,3,7,7,3,3,
    3,3,7,7,3,3,7,7,3,3,7,7,3,3,7,7,
    3,3,7,7,3,3,7,7,3,3,7,7,3,3,7,7,
    7,7,3,3,7,7,3,3,7,7,3,3,7,7,3,3,
    7,7,3,3,7,7,3,3,7,7,3,3,7,7,3,3,
    3,3,7,7,3,3,7,7,3,3,7,7,3,3,7,7,
    3,3,7,7,3,3,7,7,3,3,7,7,3,3,7,7,
    7,7,3,3,7,7,3,3,7,7,3,3,7,7,3,3,
    7,7,3,3,7,7,3,3,7,7,3,3,7,7,3,3
  };
  static dt_ntype_b08_t segmented_data[NCOLS*NROWS] = {
    1,1,1,1,2,2,2,2,1,1,1,1,2,2,2,2,
    1,1,1,1,2,2,2,2,1,1,1,1,2,2,2,2,
    1,1,1,1,2,2,2,2,1,1,1,1,2,2,2,2,
    1,1,1,1,2,2,2,2,1,1,1,1,2,2,2,2,
    2,2,2,2,1,1,1,1,2,2,2,2,1,1,1,1,
    2,2,2,2,1,1,1,1,2,2,2,2,1,1,1,1,
    2,2,2,2,1,1,1,1,2,2,2,2,1,1,1,1,
    2,2,2,2,1,1,1,1,2,2,2,2,1,1,1,1,
    1,1,1,1,2,2,2,2,1,1,1,1,2,2,2,2,
    1,1,1,1,2,2,2,2,1,1,1,1,2,2,2,2,
    1,1,1,1,2,2,2,2,1,1,1,1,2,2,2,2,
    1,1,1,1,2,2,2,2,1,1,1,1,2,2,2,2,
    2,2,2,2,1,1,1,1,2,2,2,2,1,1,1,1,
    2,2,2,2,1,1,1,1,2,2,2,2,1,1,1,1,
    2,2,2,2,1,1,1,1,2,2,2,2,1,1,1,1,
    2,2,2,2,1,1,1,1,2,2,2,2,1,1,1,1
  };

  DT_Q(dtlev85_test,(param,			/* make images					    */
    &segmented_data[0],
    &gray_data[0],
    NCOLS, NROWS, 
    0.0,								/* background value				    */
    0.0,    0,							/* background results			    */
    0.5,   16,							/* foreground					    */
    0.5,   16,							/* combined						    */
    assert_fail, F));

#undef NCOLS
#undef NROWS
    
  return DT_RC_GOOD;
}
/*..........................................................................
 * having half the image with 0 variance raises the total uniformity to .75
 *..........................................................................*/

dt_rc_e
dtlev85_test6(
  dtparam_t *param,
  int *assert_fail)
{
  DT_F("dtlev85_test6");
  dt_ctl_t *ctl = &param->ctl;

#define NCOLS 16
#define NROWS 16
  static dt_ntype_b08_t gray_data[NCOLS*NROWS] = {
    5,5,5,5,5,5,5,5,3,3,7,7,3,3,7,7,
    5,5,5,5,5,5,5,5,3,3,7,7,3,3,7,7,
    5,5,5,5,5,5,5,5,7,7,3,3,7,7,3,3,
    5,5,5,5,5,5,5,5,7,7,3,3,7,7,3,3,
    5,5,5,5,5,5,5,5,3,3,7,7,3,3,7,7,
    5,5,5,5,5,5,5,5,3,3,7,7,3,3,7,7,
    5,5,5,5,5,5,5,5,7,7,3,3,7,7,3,3,
    5,5,5,5,5,5,5,5,7,7,3,3,7,7,3,3,
    5,5,5,5,5,5,5,5,3,3,7,7,3,3,7,7,
    5,5,5,5,5,5,5,5,3,3,7,7,3,3,7,7,
    5,5,5,5,5,5,5,5,7,7,3,3,7,7,3,3,
    5,5,5,5,5,5,5,5,7,7,3,3,7,7,3,3,
    5,5,5,5,5,5,5,5,3,3,7,7,3,3,7,7,
    5,5,5,5,5,5,5,5,3,3,7,7,3,3,7,7,
    5,5,5,5,5,5,5,5,7,7,3,3,7,7,3,3,
    5,5,5,5,5,5,5,5,7,7,3,3,7,7,3,3
  };
  static dt_ntype_b08_t segmented_data[NCOLS*NROWS] = {
    3,3,3,3,3,3,3,3,1,1,1,1,2,2,2,2,
    3,3,3,3,3,3,3,3,1,1,1,1,2,2,2,2,
    3,3,3,3,3,3,3,3,1,1,1,1,2,2,2,2,
    3,3,3,3,3,3,3,3,1,1,1,1,2,2,2,2,
    3,3,3,3,3,3,3,3,2,2,2,2,1,1,1,1,
    3,3,3,3,3,3,3,3,2,2,2,2,1,1,1,1,
    3,3,3,3,3,3,3,3,2,2,2,2,1,1,1,1,
    3,3,3,3,3,3,3,3,2,2,2,2,1,1,1,1,
    3,3,3,3,3,3,3,3,1,1,1,1,2,2,2,2,
    3,3,3,3,3,3,3,3,1,1,1,1,2,2,2,2,
    3,3,3,3,3,3,3,3,1,1,1,1,2,2,2,2,
    3,3,3,3,3,3,3,3,1,1,1,1,2,2,2,2,
    3,3,3,3,3,3,3,3,2,2,2,2,1,1,1,1,
    3,3,3,3,3,3,3,3,2,2,2,2,1,1,1,1,
    3,3,3,3,3,3,3,3,2,2,2,2,1,1,1,1,
    3,3,3,3,3,3,3,3,2,2,2,2,1,1,1,1
  };

  DT_Q(dtlev85_test,(param,				/* make images					    */
    &segmented_data[0],
    &gray_data[0],
    NCOLS, NROWS, 
    0.0,								/* background value				    */
    0.0,    0,							/* background results			    */
    0.75,   9,							/* foreground					    */
    0.75,   9,							/* combined						    */
    assert_fail, F));

#undef NCOLS
#undef NROWS
    
  return DT_RC_GOOD;
}
#endif
