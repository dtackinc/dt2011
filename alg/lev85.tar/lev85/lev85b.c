/* example program dtlev85b                                                 */
/* illustrates dtlev85_label()                                              */
/* three arguments are: 1) the gray level image filename,                   */
/* 2) the segmented image filename, and 3) the background value             */
/*     dtlev85a data/dice64.pgm data/dice64s.pgm 0                          */
/* uniformity of each non-background label is computed and printed          */
/* all error checking left out for clarity                                  */

#include <dt.h>
#include <dtlev85.h>

dt_rc_e mycallback(                   /* callback routine just prints       */
  dt_ctl_t *ctl,
  void *callback_arg,
  double label,
  dtlev85_t *lev85)
{
  printf(
    "label %2d: uniformity %0.5f"
    " over %ld regions"
    " of total area %ld\n",
    (int)label,
    lev85->u, lev85->n, lev85->Aa);
  return DT_RC_GOOD;
}

void main(int argc, char *argv[])
{
  dtimage_t gray;
  dtimage_t segmented;
  double background;
  dtimage_import(NULL,                /* read and allocate gray image       */
    &gray, argv[1]);
  dtimage_import(NULL,                /* read and allocate segmented image  */
    &segmented, argv[2]);
  background = atol(argv[3]);         /* get background from command line   */

  dtlev85_label(NULL, &gray,          /* compute uniformity by labels       */
    &segmented, background,
    mycallback, NULL);                /* call mycallback for each label     */
}
