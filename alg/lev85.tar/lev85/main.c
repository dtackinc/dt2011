/*..........................................................................
| NAME
| dtlev85 sample program - Levine&Nazif 1985
| 
| DESCRIPTION
| As yet undocumented.
| 
| RETURN VALUES
| Program exit value will be DT_EXIT_GOOD on success.  
| Any other exit value indicates failure or noncompletion.
| 
| ERRORS
| As yet undocumented.
| 
| END
 *..........................................................................*/


#include <dt.h>
#include <dtlev85.h>

DT_RCSID("util $RCSfile: main.c,v $ $Revision: 1.2 $");

int main(
  int argc,
  char *argv[])
{
  return (int)dtlev85_cmd(argc, argv);
}


