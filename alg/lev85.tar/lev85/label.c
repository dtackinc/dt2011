#include <dt.h>
DT_RCSID("alg/lev85 $RCSfile: label.c,v $ $Revision: 1.9 $");
#include <dtlev85.h>
#include <dtos.h>
#include <dtmem.h>

static dtimage_adj_callback_f dtlev85_label_adjcallback;

typedef struct {
  double label;
  double maxlabel;
  dtlev85_t *lev85;
} label_arg_t;
  
/*..........................................................................
| NAME
| dtlev85_label() - uniformity for each label
| 
| DESCRIPTION
| dtlev85_label() computes a uniformity number for each unique
| non-background label found in the input ~segmented~ image.
|_index uniformity,, by label
|_index label uniformity,, computing
|
| Uniformity values are computed using ~gray~ image pixels from
| regions defined by 4-connected pixels in the ~segmented~ image.
| The caller-supplied ~callback~ routine is called
| once for each different label found in the ~segmented~ image.
| 
| The ~lev85~ structure passed to the callback routine represents
| the uniformity of an area comprised of all regions whose pixel
| value in the ~segmented~ image was ~label~.
| 
| The uniformity measure is passed to ~callback~ in ~lev85->u~.
| The number of regions contributing to the uniformity is passed in
| ~lev85->n~.
| 
| Regions in ~segmented~ whose values are ~background~ are ignored.
| Regions in ~segmented~whose values are greater than or equal to
| ~param->max~ are also ignored.
| 
| The value of ~callback_arg~ is passed unchanged from dtlev85_label()
| into ~callback~.
| 
| Consider the small images below in which a value of ":.:"
| indicates a pixel of background value which is ignored:
| 
|:    segmented image               gray level image
|:  . . . . . . . . . .       .. .. .. .. .. .. .. .. .. ..
|:  . 1 1 1 . . 2 2 2 .       .. 23 24 23 .. .. 45 47 43 ..
|:  . 1 1 1 . . 2 2 2 .       .. 25 25 24 .. .. 45 46 44 ..
|:  . 1 1 1 . . 2 2 2 .       .. 23 26 24 .. .. 46 44 45 ..
|:  . . . . . . . . . .       .. .. .. .. .. .. .. .. .. ..
|:  . 6 6 6 . . 1 1 1 .       .. 73 74 73 .. .. 35 37 33 ..
|:  . 6 6 6 . . 1 1 1 .       .. 75 75 74 .. .. 35 36 34 ..
|:  . 6 6 6 . . 1 1 1 .       .. 73 76 74 .. .. 36 34 35 ..
|:  . . . . . . . . . .       .. .. .. .. .. .. .. .. .. ..
| 
| Three calls would be made to the ~callback~ routine.
| label 1:	two regions, gray values in the 20's and 30's
| label 2:	one region, gray values in the 40's
| label 6:	one region, gray values in the 70's
|
| No ~label~ passed to the callback routine will have the value ~background~
| or will have a value at or above the maximum label.
| The maximum label is either ~param->max~ if set,
| otherwise 255.
| 
| This routine is most useful when the labels in the segmented
| image truly represent distinct objects for which a uniformity
| measure is meaningful.
| These objects need not be geometrically connected:
| multiple disconnected regions, if given the same label,
| will all contribute to one uniformity.
| 
| Since this routine passes no geometric information to the
| ~callback~ routine, it is not suitable for applications
| which must access the region's pixels on which the uniformity
| is being calculated.
|
| CAVEATS
| The ~background~ value refers to a particular pixel value in
| the ~segmented~ image, not one from the ~gray~ image.
| Any pixels in the ~segmented~ image whose values are equal to
| ~background~ are silently ignored.
|
| Any pixels in the ~segmented~ image whose values are greater than
| ~param->max~ are silently ignored.
| 
| No geometric information about the regions is made available
| to the ~callback~ routine.
|
| Don't confuse the callback used by this function with the
| callback used by the connected components processing.
| The callback used by this function is done on a per-label basis,
| whereas the connected components callback is done
| on a connected-pixel basis.
| 
| PARAMETERS
| ~param->max~ is the maximum label value to be considered.
| Only label values of 0 through ~param->max~, inclusive, will be considered
| as label values, except the label value equal to ~background~.
| Default is 255 if ~param->max_flag~ indicates that ~param->max~ does not
| have an assigned value.
|_index param,, max, dtlev85_label()
|
| EXAMPLE lev85b.c
|:// example program dtlev85b
|:// illustrates dtlev85_label()
|:// three arguments are: 1) the gray level image filename, 
|:// 2) the segmented image filename, and 3) the background value
|://     dtlev85a data/dice64.pgm data/dice64s.pgm 0
|:// uniformity of each non-background label is computed and printed
|:// all error checking left out for clarity
|:
|:#include <dt.h>
|:#include <dtlev85.h>
|:
|:dt_rc_e mycallback(					// callback routine just prints
|:  dt_ctl_t *ctl,		
|:  void *callback_arg,	
|:  double label,		
|:  dtlev85_t *lev85)	
|:{
|:  printf(
|:    "label %2d: uniformity %0.5f"
|:    " over %ld regions"
|:    " of total area %ld\n", 
|:    (int)label,
|:    lev85->u, lev85->n, lev85->Aa);
|:  return DT_RC_GOOD;
|:}
|:
|:void main(int argc, char *argv[])
|:{
|:  dtimage_t gray;
|:  dtimage_t segmented;
|:  double background;
|:  dtimage_import(NULL,		 		// read and allocate gray image
|:    &gray, argv[1]);
|:  dtimage_import(NULL,		 		// read and allocate segmented image
|:    &segmented, argv[2]);
|:  background = atol(argv[3]);			// get background from command line
|:
|:  dtlev85_label(NULL, &gray,			// compute uniformity by labels
|:    &segmented, background, 
|:    mycallback, NULL);				// call mycallback for each label
|:}
|
| RETURN VALUES
| There are no return values.
| If desired, the callback routine may values in the ~callback_arg~
| structure for passing back to the calling routine.
|dtinclude(return1.dx)
| 
| ERRORS
| Unsuccessful completion may be due to:
| - ~gray~ image does not have a valid data type
| - ~segmented~ image does not have a valid data type
| - unable to allocate space for the temporary lev85 structures
| - unable to allocate space for the temporary histogram
| - error during connected components analysis
| 
| SEE ALSO
| dtlev85_total()		calculate single uniformity for all regions
|
| END
 *..........................................................................*/

/*..........................................................................
| Compute uniformity measure for each different label value found in the
| segmented image.
| Callback function is called once for each label.
| The ~id~ member of the lev85 structure given to the callback function
| identifies the label.
 *..........................................................................*/

dt_rc_e
dtlev85_label(
  dtparam_t *param,						/* control parameter structure 		*/
  dtimage_t *gray,						/* input gray gray-level image		*/
  dtimage_t *segmented,					/* input segmented image			*/
  double background,					/* background in segmented image    */
  dtlev85_callback_f callback,			/* function called for each label 	*/
  void *callback_arg)					/* arg passed through to callback 	*/
{
  static char *F = "dtlev85_label";
  dt_ctl_t *ctl = param? 
    &param->ctl: NULL;
  dtlev85_t *lev85 = NULL;
  dthist_t hist;
  label_arg_t label_arg;
  int i;
  dt_rc_e rc;
  unsigned int param_max = 
    (int)DTPARAM_GET_VALUE(				/* get "max" param				    */
      max, DTLEV85_MAXLABEL);

  hist.freq = NULL;

  rc = dtimage_check_1f(ctl,			/* check simple stuff				*/
    gray, "gray",
    DTLEV85_GRAY_NTYPE_LIST,			/* gray ntypes are constrained		*/
    DTIMAGE_FLAG_PAGED, F);
  if (rc != DT_RC_GOOD)
    return rc;

  rc = dtimage_check_1f(ctl,			/* check simple stuff				*/
    segmented, "segmented",
    NULL,								/* segmented ntype can be any 		*/
    DTIMAGE_FLAG_PAGED, F);
  if (rc != DT_RC_GOOD)
    return rc;

  DT_C(dtos_malloc2,(ctl,				/*[Get space for one lev85	   	   ]*/
    (void **)&lev85,					/*[structure for each possible 	   ]*/
    (param_max + 1) * sizeof(*lev85),	/*[label value.					   ]*/
    F, "lev85 structures"));

  DT_C(dtimage_hist_alloc,(ctl, gray,	/*[Get space for the histogram.	   ]*/
    &hist));

  DT_C(dtlev85_init,(param, lev85,		/*[Init lev85 structures.	       ]*/
    param_max+1, gray, &hist));

  memset(&label_arg, 0,
    sizeof(label_arg));
  label_arg.lev85 = lev85;				/* prepare communication structure	*/
  label_arg.maxlabel = param->max;

  DT_C(dtimage_adj,(ctl,				/*[Perform connection components   ]*/
    segmented,							/*[analysis, accumulating lev85    ]*/
    0, 0,								/*[structures for each label.	   ]*/
    DT_MIN(gray->xe,
      segmented->xe),
    DT_MIN(gray->ye,
      segmented->ye),
    background,		
    dtlev85_label_adjcallback,
    (void **)&label_arg));

  for (i=0; i<param_max+1; i++)			/*[For each label value 	   	   ]*/
  {
	if (lev85[i].n)						/*[which had any regions,		   ]*/
	{
      DT_C(dtlev85_compute,(param,		/*[compute uniformity for label,   ]*/
        &lev85[i]));
	  DT_G(callback,(ctl,				/*[and give uniformity to caller.  ]*/
        callback_arg, i, &lev85[i]));
	  if (rc == DT_RC_STOP)				/*[Stop scanning if callback	   ]*/
	  {									/*[returns DT_RC_STOP. 			   ]*/
        rc = DT_RC_GOOD;
		goto cleanup;
	  }
	}
  }
  
cleanup:
  if (hist.freq)
    DT_I(dthist_free,(ctl, &hist));		/*[Free space for the histogram.   ]*/
  if (lev85)
    DT_I(dtos_free2,(ctl, lev85,		/*[Free lev85 structures. 		   ]*/
      F, "lev85 structures"));

  return rc;
}

/*..........................................................................
 * example for documentation/example purposes only
 *..........................................................................*/

dt_rc_e
dtlev85_label_callback(					/* caller-provided function 		*/
  dt_ctl_t *ctl,						/* environment control structure 	*/
  void *callback_arg,					/* passed through from application 	*/
  double label,							/* input current label value 		*/
  dtlev85_t *lev85)						/* input computed uniformity 		*/
{
  dt_say(ctl, NULL,
    "label %2d: uniformity %0.5f"
    " over %ld regions"
    " of total area %ld", 
    (int)label,
    lev85->u, lev85->n, lev85->Aa);
  return DT_RC_GOOD;
}

/*..........................................................................
 * called for each pixel-rectangle by dtimage_adj_callback
 *..........................................................................*/

static
dt_rc_e
dtlev85_label_adjcallback(
  dt_ctl_t *ctl,
  dtimage_adj_callback_arg_t *arg,
  dtxy_t x1,
  dtxy_t y1,
  dtxy_t x2,
  dtxy_t y2)
{
  DT_F("dtlev85_label_adjcallback");
  label_arg_t *label_arg =
    (label_arg_t *)arg->arg;
  unsigned int ilabel =					/* current label value of blob		*/
    (unsigned int)label_arg->label;
  dtlev85_t *lev85 =					/* lev85 structure for this label 	*/
    &label_arg->lev85[ilabel];
  int flag = arg->flag;
  int x, y;

  arg->flag = 0;						/* clear flag for next blob		    */

  if (flag & DTIMAGE_ADJ_FLAG_END &&	/* finishing an old blob?			*/
	  label_arg->label <=				/* old blob is legal?				*/
	  label_arg->maxlabel)
  {
	DT_Q(dtlev85_contribute,(			/* region contributes to uniformity	*/
      lev85->param, lev85));
    if (!(flag & DTIMAGE_ADJ_FLAG_BEG))	/* not also starting a new blob?	*/
      return DT_RC_GOOD;
  }

  if (flag & DTIMAGE_ADJ_FLAG_BEG)		/* starting a new blob?				*/
  {
	label_arg->label = arg->label;		/* remember label of blob 			*/
	if (label_arg->label >				/* starting an illegal blob?		*/
		label_arg->maxlabel)
	  return DT_RC_GOOD;

  	ilabel = (unsigned int)
      label_arg->label;
	lev85 = &label_arg->lev85[ilabel];
    DT_Q(dthist_clear,(ctl,				/* clear histogram					*/
      lev85->hist));
  }

  if (label_arg->label <=				/* working on a legal blob?			*/
      label_arg->maxlabel)	
  {
    for (y=y1; y<=y2; y++)				/* for rows in this piece of blob 	*/
    {
	  void *p;
	  DTIMAGE_GETROW(ctl,				/* address gray row 				*/
        lev85->gray, y, &p);
	  DT_Q(dthist_add_values,(ctl,		/* sum histogram frequencies 		*/
        lev85->hist, p, x1, x2+1,		/* in this peace of blob 			*/
        lev85->gray->ntype));
	  DTIMAGE_UNMAPROW(ctl,				/* de-address gray row 				*/
        lev85->gray, y);
    }
  }
    
  return DT_RC_GOOD;					/* keep doing blobs				    */
}
