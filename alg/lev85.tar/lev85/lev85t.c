/*..........................................................................
| TITLE
| Algorithm: dtlev85
| 
| ABSTRACT
| This is an implementation of a segmentation performance measuring algorithm.
| The algorithm is due to Levine and Nazif.
| It is described completely in [lev85].
| Input consists of two images.
| The first image is the original gray level image.
| Each pixel in the second image is a label
| The second image contains pixels whose values are labels which
| indicate membership in a geographic region.
| One or more regions may be considered together as an area.
| For each area, the algorithm produces a single numeric uniformity measure.
| Uniformity values near 1.0 signify that the regions in the area
| contain pixels with similar gray level values.
| The algorithm is implemented as a C-callable library of routines.
| A simple main program provides command-line execution of the routines.
| The main program has an option for verifying the correctness
| of the implementation.
| The source code is modular and platform- and hardware-independent.
| Compilation instructions in the form of makefiles are provided for
| several platforms including Unix, DOS, Microsoft Windows and others. 
|
|!Overview
|_figure half, gray5.ps, Billiard Balls Gray Level
| 
|_figure half, seg5b.ps, Billiard Balls Naive Uniformity xxxx
|_figure half, seg5a.ps, Billiard Balls Better Uniformity xxxx
|
|.~What are the goals of the algorithm?~
| Given a gray level image and its segmentation,
| the algorithm attempts to provide a single number called the uniformity.
| The uniformity may be considered a measure
| of the goodness of the segmentation.
|
| EXAMPLE lev85d.c
|:// example program dtlev85d
|:// illustrates blob-based uniformity computation
|:// three arguments are: 1) the gray level image filename, 
|:// 2) the segmented image filename, and 3) the background value
|://     dtlev85a data/dice64.pgm data/dice64s.pgm 0
|:// uniformity of each non-background blob is computed and printed
|:// all error checking left out for clarity
|:
|:#include <dt.h>
|:#include <dtlev85.h>
|:
|:static int n = 0;						// global stuff
|:static unsigned long xsum, ysum;
|:static dtlev85_t lev85;
|:
|:dt_rc_e
|_aside You should write a function like this.
|:mycallback(
|:  dt_ctl_t *ctl,
|:  dtimage_adj_callback_arg_t *arg,
|:  dtxy_t x1,
|:  dtxy_t y1,
|:  dtxy_t x2,
|:  dtxy_t y2)
|:{
|:  int flag = arg->flag;
|:  dthist_freq_t * const h =			// for quick access	
|:    lev85.hist->freq;
|:  int x, y;
|:
|:  arg->flag = 0;						// clear flag for next blob	
|:
|:  if (flag & DTIMAGE_ADJ_FLAG_END)	// finishing an old blob?			
|_aside Connected components tells us blob is finished.
|:  {
|:	  dtlev85_contribute(NULL, &lev85);	// contribute blob's histogram
|:    dtlev85_compute(NULL, &lev85);	// compute blob's uniformity		
|:    printf("  blob %4d: "				// print out blob's uniformity		
|:      " area %6ld, centroid (%lu,%lu),"
|:      " uniformity %0.5f",
|:	    n++, lev85.Aa,
|:      xsum / lev85.Aa,
|:      ysum / lev85.Aa,
|:      lev85.u);
|:
|:    if (!(flag & 						// not also starting a new blob?	
|:          DTIMAGE_ADJ_FLAG_BEG))
|:      return DT_RC_GOOD;
|:  }
|:
|:  if (flag & DTIMAGE_ADJ_FLAG_BEG)	// starting a new blob?				
|:  {
|:    dtlev85_init(NULL, &lev85, 1,		// reinit lev85 structure			
|:      lev85.gray, lev85.hist);
|:    dthist_clear(ctl, lev85.hist);	// clear histogram					
|:	  xsum = 0;							// clear centroid accumulators		
|:    ysum = 0;
|:  }
|:
|:  for (y=y1; y<=y2; y++)
|_aside Add this little piece of blob to the histogram.
|:    for (x=x1; x<=x2; x++)
|:    {
|:	    h[lev85.gray->row[y].b08[x]]++;	// histogram contribution			
|:	    xsum += x;						// centroid contribution			
|:      ysum += y;
|:    }
|:    
|:  return DT_RC_GOOD;					// keep doing blobs				    
|:}
|:
|:void main(int argc, char *argv[])
|:{
|:  dtimage_t gray;
|:  dtimage_t segmented;
|:  double background;
|:  dthist_t hist;
|:
|:  dtimage_import(NULL,		 		// read and allocate gray image
|_aside Read the two input images.
|:    &gray, argv[1]);
|:  dtimage_import(NULL,		 		// read and allocate segmented image
|:    &segmented, argv[2]);
|:  background = atol(argv[3]);			// get background from command line
|:
|:  dthist_alloc(NULL,					// space for histogram
|:    &hist, DTHIST_TYPE_PACKED,
|:    dt_ntype_minval[gray.ntype],
|:    dt_ntype_maxval[gray.ntype]);
|:  dtlev85_init(NULL, &lev85, 1,		// init global lev85 structure
|:    &gray, &hist);
|:  dtimage_adj(NULL,       			// compute uniformity by blobs
|_aside Do connected components analysis.
|:    &segmented, background, 0, 
|:    mycallback, NULL);				// call mycallback for each blob
|:}
|
| END
 *..........................................................................*/
