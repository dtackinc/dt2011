#include <dt.h>
DT_RCSID("alg/lev85 $RCSfile: total.c,v $ $Revision: 1.9 $");
#include <dtlev85.h>
#include <dtmem.h>

static dtimage_adj_callback_f dtlev85_total_adjcallback;

/*..........................................................................
| NAME
| dtlev85_total() - total uniformity
| 
| DESCRIPTION
| dtlev85_total() computes a single uniformity number characterizing
| all non-background pixels in an image.
|_index uniformity,, total
|_index total uniformity,, computing
|
| The regions defined by 4-connected pixels in the ~segmented~ image 
| are extracted by connected components analysis.
| Using the corresponding locations in the ~gray~ image,
| total uniformity ~lev85->u~ is computed.
| The number of regions is returned in ~lev85->n~.
| Regions in ~segmented~ whose values are ~background~ are ignored.
|
| The total uniformity represents the uniformity of an area
| which is composed of all non-background regions in the image.
| 
| If no pixel in the ~segmented~ image has the value ~background~,
| then all pixels in the image contribute to the uniformity.
| This is desirable in some applications.
| 
| CAVEATS
| The ~background~ value refers to a particular pixel value in
| the ~segmented~image, not one from the ~gray~ image.
| Any pixels in the ~segmented~ image whose values are equal to
| ~background~ are silently ignored.
| 
| PARAMETERS
|dtinclude(ctlonly.dx)
|
| EXAMPLE lev85a.c
|:// example program dtlev85a
|:// illustrates dtlev85_label()
|:// three arguments are: 1) the gray level image filename, 
|:// 2) the segmented image filename, and 3) the background value
|://     dtlev85a data/dice64.pgm data/dice64s.pgm 0
|:// total uniformity of non-background regions is computed and printed
|:// all error checking left out for clarity
|:
|:#include <dt.h>
|:#include <dtlev85.h>
|:
|:void main(int argc, char *argv[])
|:{
|:  dtimage_t gray;
|:  dtimage_t segmented;
|:  double background;
|:  dtlev85_t lev85;
|:  dtimage_import(NULL,		 		// read and allocate gray image
|:    &gray, argv[1]);
|:  dtimage_import(NULL,		 		// read and allocate segmented image
|:    &segmented, argv[2]);
|:  background = atol(argv[3]);			// get background from command line
|:  dtlev85_total(NULL, &gray,			// compute total uniformity
|:    &segmented, background, &lev85);
|:  printf("uniformity %0.5f"			// print the uniformity
|:    " over %ld regions covering"
|:    " %ld%% of the image area",
|:    lev85.u, lev85.n,
|:    (100L * lev85.Aa) /
|:    (gray.xe * gray.ye));
|:}
|
| RETURN VALUES
| The total uniformity is returned in ~lev85->u~.
| The number of regions contributing to the uniformity is returned in
| ~lev85->n~.
| The sum of the areas of all the contributing regions is returned in
| ~lev85->Aa~.
|dtinclude(return1.dx)
| 
| ERRORS
| Unsuccessful completion may be due to:
| - ~gray~ image does not have a valid data type
| - ~segmented~ image does not have a valid data type
| - unable to allocate space for the temporary histogram
| - error during connected components analysis
| 
| SEE ALSO
| dtlev85_label()		calculate uniformity for individual regions
|
| END
 *..........................................................................*/

dt_rc_e
dtlev85_total(							/* total non-background uniformity	*/
  dtparam_t *param,						/* control parameter structure 		*/
  dtimage_t *gray,						/* input gray gray-level image		*/
  dtimage_t *segmented,					/* input segmented image			*/
  double background,					/* background in segmented image    */
  dtlev85_t *lev85)						/* returned structure 				*/
{
  static char *F = "dtlev85_total";
  dt_ctl_t *ctl = param? 
    &param->ctl: NULL;
  dthist_t hist;
  dthist_t *oldhist = lev85->hist;
  dt_rc_e rc;

  rc = dtimage_check_1f(ctl,			/* check simple stuff				*/
    gray, "gray",
    DTLEV85_GRAY_NTYPE_LIST,			/* gray ntypes are constrained		*/
    DTIMAGE_FLAG_PAGED, F);
  if (rc != DT_RC_GOOD)
    return rc;

  rc = dtimage_check_1f(ctl,			/* check simple stuff				*/
    segmented, "segmented",
    NULL,								/* segmented ntype can be any 		*/
    DTIMAGE_FLAG_PAGED, F);
  if (rc != DT_RC_GOOD)
    return rc;

  hist.freq = NULL;

  DT_C(dtimage_hist_alloc,(ctl, gray,	/*[Get space for the histogram.	   ]*/
    &hist));
  
  DT_C(dtlev85_init,(param, lev85, 1,	/*[Initialize lev85 structure.	   ]*/
    gray, &hist));

  DT_C(dtimage_adj,(ctl,				/*[Perform connected components	   ]*/
    segmented,							/*[analysis. 				   	   ]*/
    0, 0,			
    DT_MIN(gray->xe,
      segmented->xe),
    DT_MIN(gray->ye,
      segmented->ye),
    background, 
    dtlev85_total_adjcallback,			/*[Use our own callback routine,   ]*/
    lev85));							/*[passing it the lev85 structure. ]*/

  DT_C(dtlev85_compute,(param,			/*[Compute final uniformity value. ]*/
	lev85));

cleanup:
  if (hist.freq != NULL)
    DT_I(dthist_free,(ctl, &hist));		/*[Free space for the histogram.   ]*/
  lev85->hist = oldhist;
  return rc;
}

/*..........................................................................
 * called for each pixel-rectangle by dtimage_adj_callback
 *..........................................................................*/

static
dt_rc_e
dtlev85_total_adjcallback(
  dt_ctl_t *ctl,
  dtimage_adj_callback_arg_t *arg,
  dtxy_t x1,
  dtxy_t y1,
  dtxy_t x2,
  dtxy_t y2)
{
  DT_F("dtlev85_total_adjcallback");
  dtlev85_t *lev85 = (dtlev85_t *)arg->arg;
  int flag = arg->flag;
  dthist_freq_t * const freq =
    lev85->hist->freq;
  int x, y;

  arg->flag = 0;						/* clear flag for next blob		    */

  if (flag & DTIMAGE_ADJ_FLAG_END)		/* finishing an old blob?			*/
  {
	DT_Q(dtlev85_contribute,(			/* region contributes to uniformity	*/
      lev85->param, lev85));
    if (!(flag & DTIMAGE_ADJ_FLAG_BEG))	/* not also starting a new blob?	*/
      return DT_RC_GOOD;
  }

  if (flag & DTIMAGE_ADJ_FLAG_BEG)		/* starting a new blob?				*/
    DT_Q(dthist_clear,(ctl,				/* clear histogram					*/
      lev85->hist));

    for (y=y1; y<=y2; y++)				/* for rows in this piece of blob 	*/
    {
	  void *p;
	  DTIMAGE_GETROW(ctl,				/* address gray row 				*/
        lev85->gray, y, &p);
	  DT_Q(dthist_add_values,(ctl,		/* sum histogram frequencies 		*/
        lev85->hist, p, x1, x2+1,		/* in this peace of blob 			*/
        lev85->gray->ntype));
	  DTIMAGE_UNMAPROW(ctl,				/* de-address gray row 				*/
        lev85->gray, y);
    }
    
  return DT_RC_GOOD;					/* keep doing blobs				    */
}
