/* example program dtlev85c                                                 */
/* illustrate dtlev85_init(), dtlev85_contribute(), and dtlev85_compute()   */
/* single argument is the gray level image filename, such as:               */
/*     dtlev85c data/dice64.pgm                                             */
/* uniformity of image taken as monolithic region is computed and printed   */
/* all error checking left out for clarity                                  */
#include <dt.h>
#include <dtlev85.h>
void main(int argc, char *argv[])
{
  dtimage_t seg;
  dtimage_t gray;
  dthist_t hist;
  dtlev85_t lev85;
  dtimage_import(NULL,                /* read and allocate gray image       */
    &gray, argc>1? argv[1]: "");
  dtimage_create(NULL, &seg,          /* create space for segmented image   */
    gray.xe, gray.ye, DT_NTYPE_B08);  /* same size as gray image            */
  dtimage_constant(NULL, &seg, 1);    /* make one giant blob of 1's         */
  dtimage_hist_alloc(NULL, &gray,     /* space for histogram                */
    &hist);
  dtimage_hist(NULL, &gray,           /* get histogram of gray image        */
    &hist);
  dtlev85_init(NULL, &lev85, 1,       /* initialize lev85 structure         */
    &gray, &hist);
  dtlev85_contribute(NULL, &lev85);   /* contribute giant blob              */
  dtlev85_compute(NULL, &lev85);      /* compute final uniformity           */
  printf("uniformity %e\n",           /* print the uniformity               */
    lev85.u);
}
