/*..........................................................................
| USAGE
| dtlev85 - algorithm executive
| 
|.SYNOPSIS
|:dtlev85 [parameters] gray segmented
| 
|.SUMMARY
| Compute a uniformity number characterizing the goodness of a segmentation.
| Output is a single number which is printed. 
| Algorithm due to Levine and Nazif, 1985.
| 
|.ARGUMENTS
| :segmented:	name of the image which has been segmented
| :gray:	   	name of the original gray-level image
|
|.PARAMETERS
| :-background:	segmented pixels to be considered background (default 0)
| :-op:			operation, one of {total test time} (default total)
|dtinclude(params1.dx)
| 
|.DESCRIPTION
| Presumes that ~segmented~ is the segmented form of the ~gray~ image.
| In ~segmented~, the value of the pixel indicates the region number.
| All 4-connected pixels in with the same value are considered
| to be part of the same region.
| Segmentation may have been done by any means.
|
|.OPERATIONS 
| The :-op: parameter may take one of the following values:
| :total:	perform algorithm on input to produce output
| :test:	perform implementation self-tests and display pass/fail result
| :time:	perform implementation benchmark and display execution times
|
|.PAGING
| The :test: and :time: operations may be exercised under varying paging 
| configurations.
| The minimum no-dialog configurations are:
| :-op test:		maxalloc 16384, pagesize 128, npages 1
| :-op time:		maxalloc 262144, pagesize 512, npages 1
|
|dtinclude(params2.dx)
|
| END
 *..........................................................................*/


#include <dt.h>
DT_RCSID("alg/lev85 $RCSfile: cmd.c,v $ $Revision: 1.7 $");
#include <dtlev85.h>
#include <dtstr.h>
#include <dtos.h>
#include <dtmem.h>

#include <lev85.use>

# define OP_TOTAL  "total"
# define OP_LABEL   "label"
# define OP_BLOB    "blob"
# define OP_OUT     "out"
# define OP_TEST    "test"
# define OP_TIME    "time"


#define OUT_BACKGROUND (0.5)
#define OUT_BUILDING (0.0)

static const char *ops[] = {
  OP_TOTAL,
  OP_LABEL,
  OP_BLOB,
  OP_OUT,
  OP_TEST,
  OP_TIME,
  NULL
};

typedef struct {						/* passed to label callback 		*/
  int n;
} label_arg_t;

typedef struct {						/* passed to blob callback 			*/
  dtlev85_t this_lev85;					/* single blob uniformity			*/
  dtlev85_t total_lev85;				/* accumulate total uniformity		*/
  int n;								/* blob counter 					*/
  int v;								/* current blob label  				*/
} blob_arg_t;

typedef struct {						/* passed to out callback 			*/
  dtimage_t *output;
  dtlev85_t lev85;						/* single blob uniformity			*/
  dtxy_t xseed;
  dtxy_t yseed;
  dtxy_t xmin, ymin, xmax, ymax;
} out_arg_t;

/*..........................................................................
| NAME
| dtlev85_cmd - command line interface to algorithm
| 
| DESCRIPTION
| As yet undocumented.
| 
| RETURN VALUES
| Program exit value will be DT_EXIT_GOOD on success.  
| Any other exit value indicates failure or noncompletion.
| 
| ERRORS
| As yet undocumented.
| 
| END
 *..........................................................................*/

dt_rc_e
dtlev85_cmd(
  int argc,
  char *argv[])
{
  DT_F("dtlev85_cmd");
  dtparam_t param_space;				/* parameter structure				*/
  dtparam_t *param = &param_space;
  dt_ctl_t *ctl = &param->ctl;
# define ARG_MAXLEN 128
  char segmented[ARG_MAXLEN];
  char gray[ARG_MAXLEN];
  char output[ARG_MAXLEN];
  dt_interactive_arg_t arg[4];
  dt_rc_e rc = DT_RC_GOOD;

  memset(param, 0, sizeof(*param));

  DT_GI(dt_heapmon_init,(ctl));         /* init memory checking             */
										/* ................................ */
  DT_GI(dt_interactive_enter,(ctl,		/* init interactive environment		*/
    "dtlev85", argc, argv));

  DT_GI(dtparam_init,(param));			/* init param structure             */


  DT_GI(dtparam_set,(param,			/* set default for params we want	*/
    DTPARAM_FLAG_PRIMARY,
    &param->background, 
      "Segmented background",  
      NULL, "0",
    &param->min, 
      "Minimum region area",  
      NULL, "0",
    &param->max, 
      "Maximum label value",
      NULL, DTLEV85_MAXLABEL_STRING,
    NULL));

  DT_GI(dtparam_set,(param,			/* defaults for secondary params 	*/
    DTPARAM_FLAG_SECONDARY,
    &param->op, NULL, NULL, OP_TOTAL,
    NULL));

  DT_GI(dt_interactive_arg,(ctl,		/* set up positionals			    */
    arg,
    "Gray image", NULL, 
      gray, sizeof(gray),
    "Segmented image", NULL, 
      segmented, sizeof(segmented),
    "Output image", NULL, 
      output, sizeof(output),
    NULL));

  DT_GI(dt_interactive_dialog,(ctl,		/* interactively parse command line	*/
    param, argc, argv, 
    usage, arg, dtlev85_cmd_check));
										/* ................................ */
  while (rc == DT_RC_GOOD)
  {
    if (!strcmp(param->op, OP_TOTAL))	/* ................................ */
	{
      DT_GI(dtlev85_cmd_total,			/* import images, do the operation	*/
        (param, gray, segmented));
	}
	else
    if (!strcmp(param->op, OP_LABEL))	/* ................................ */
	{
	  DT_GI(dtlev85_cmd_label,(
        param, gray, segmented));
	}
	else
    if (!strcmp(param->op, OP_BLOB))		/* ................................ */
	{
	  DT_GI(dtlev85_cmd_blob,(
        param, gray, segmented));
	}
	else
    if (!strcmp(param->op, OP_OUT))		/* ................................ */
	{
	  DT_GI(dtlev85_cmd_output,(
        param, gray, segmented,
        output,
        DT_CAST(dtxy_t,					/* image exported x position 		*/
          DTPARAM_GET_VALUE(x,			/* from -x arg 						*/
            DTIMAGE_NOPOS)),			/* or use window system default 	*/
        DT_CAST(dtxy_t,					/* image exported y position 		*/
          DTPARAM_GET_VALUE(y,			/* from -y arg 						*/
            DTIMAGE_NOPOS))));			/* or use window system default 	*/
	}
	else
    if (!strcmp(param->op, OP_TEST))	/* ................................ */
	{
      int assert_fail = 0;
      DT_GI(dtlev85_test_all,(param,	/* do the operation				    */
        &assert_fail));

      if (rc == DT_RC_GOOD &&			/* test worked?					    */
          assert_fail)					/* but some results wrong?		    */
        rc = DT_RC_BAD;
	}
	else
    if (!strcmp(param->op, OP_TIME))	/* ................................ */
	{
      int assert_fail = 0;
      DT_GI(dtlev85_time_all,(param,	/* do the operation				    */
        &assert_fail));

      if (rc == DT_RC_GOOD &&			/* test worked?					    */
          assert_fail)					/* but some results wrong?		    */
        rc = DT_RC_BAD;
	}

    DT_G(dt_interactive_after,(			/* make post display				*/
      ctl, param, usage, arg,
      dtlev85_cmd_check, rc));
  } 

  if (rc == DT_RC_STOP)
    rc = DT_RC_GOOD;

  DT_I(dt_interactive_leave,(			/* clean up before leaving			*/
    param, rc));

  {
	int check_fail = 0;
    DT_I(dt_heapmon_uninit,(ctl,		/* check all memory is freed        */
      &check_fail));
    if (check_fail)                      /* any failed assertions?           */
      rc = DT_RC_BAD;
    else
      rc = DT_RC_GOOD;
  }

  return rc;
}

/*..........................................................................*/

dt_rc_e
dtlev85_cmd_total(						/* import images and to uniformity	*/
  dtparam_t *param,
  char *gray_name,
  char *segmented_name)
{
  DT_F("dtlev85_cmd_total");
  dt_ctl_t *ctl = &param->ctl;
  dtimage_t gray, segmented;			/* image structures					*/
  dtlev85_t lev85;
  dt_rc_e rc;

  gray.xe = 0;
  segmented.xe = 0;

  DT_C(dtimage_import,(ctl,				/* get gray image					*/
    &gray, gray_name));

  DT_C(dtimage_import,(ctl,				/* get segmented image				*/
    &segmented, segmented_name));

  DT_C(dtlev85_total,(param,			/* compute uniformity				*/
    &gray, &segmented,
    param->background,
    &lev85));

  printf(								/* print uniformity				    */
    "total uniformity %0.5f"
    " over %ld regions\n",
    lev85.u, lev85.n);
  
cleanup:
  if (segmented.xe)						/* segmented image got allocated?	*/
  DT_I(dtimage_free,(ctl,				/* free it							*/
    &segmented));

  if (gray.xe)							/* gray image got allocated?	    */
  DT_I(dtimage_free,(ctl,				/* free it						    */
    &gray));

  return rc;
}

/*..........................................................................*/

dt_rc_e
dtlev85_cmd_label(						/* import images and do uniformity	*/
  dtparam_t *param,
  char *gray_name,
  char *segmented_name)
{
  DT_F("dtlev85_cmd_label");
  dt_ctl_t *ctl = &param->ctl;
  dtimage_t segmented, gray;			/* image structures					*/
  label_arg_t label_arg;
  dt_rc_e rc;

  gray.xe = 0;
  segmented.xe = 0;

  DT_C(dtimage_import,(ctl,				/* get gray image					*/
    &gray, gray_name));

  DT_C(dtimage_import,(ctl,				/* get segmented image				*/
    &segmented, segmented_name));
  
  label_arg.n = 0;
  DT_C(dtlev85_label,(					/* get contributions for each label */
    param, &gray, &segmented,
	param->background,
    dtlev85_cmd_label_callback,
    &label_arg));
  
  printf(
    "%d labels encountered\n",
    label_arg.n);

cleanup:
  if (segmented.xe)						/* segmented image got allocated?	*/
  DT_I(dtimage_free,(ctl,				/* free it							*/
    &segmented));

  if (gray.xe)							/* gray image got allocated?	    */
  DT_I(dtimage_free,(ctl,				/* free it						    */
    &gray));

  return rc;
}

/*..........................................................................*/

dt_rc_e
dtlev85_cmd_blob(						/* import images and do uniformity	*/
  dtparam_t *param,
  char *gray_name,
  char *segmented_name)
{
  DT_F("dtlev85_cmd_blob");
  dt_ctl_t *ctl = &param->ctl;
  dtimage_t segmented, gray;			/* image structures					*/
  blob_arg_t callback_arg;
  dthist_t hist;
  dt_rc_e rc;

  gray.xe = 0;
  segmented.xe = 0;
  hist.freq = NULL;

  DT_C(dtimage_import,(ctl,				/* get gray image					*/
    &gray, gray_name));

  rc = dtimage_check_1f(ctl,			/* check simple stuff				*/
    &gray, "gray",
    DTLEV85_GRAY_NTYPE_LIST,			/* gray ntypes are constrained		*/
    DTIMAGE_FLAG_PAGED, F);
  if (rc != DT_RC_GOOD)
    goto cleanup;

  DT_C(dtimage_import,(ctl,				/* get segmented image				*/
    &segmented, segmented_name));

  DT_C(dtimage_hist_alloc,(ctl, &gray,	/* get space for the histogram	    */
    &hist));

  DT_C(dtlev85_init,(param,				/* prepare for uniformity computing */
    &callback_arg.total_lev85, 1, 
    &gray, &hist));
  callback_arg.n = 0;
  
  DT_C(dtimage_adj,(ctl,				/* use callback on each blob		*/
    &segmented,
    0, 0,
    DT_MIN(gray.xe,						/* use minimum image size 			*/
      segmented.xe),
    DT_MIN(gray.ye,
      segmented.ye),
    param->background,					/* background is invisible			*/
    dtlev85_cmd_blob_callback,
    &callback_arg));
  
  DT_C(dtlev85_compute,(param,			/* compute total uniformity 		*/
    &callback_arg.total_lev85));

  printf(
    "%d (%ld) blobs encountered,"
    " total area %ld,"
    " total uniformity %0.5f\n",
    callback_arg.n,
    callback_arg.total_lev85.n,
    callback_arg.total_lev85.Aa,
    callback_arg.total_lev85.u);

cleanup:
  if (hist.freq != NULL)
    DT_I(dthist_free,(ctl, &hist));		/* free space for the histogram.   	*/

  if (gray.xe)							/* gray image got allocated?	    */
    DT_I(dtimage_free,(ctl,				/* free it						    */
      &gray));

  if (segmented.xe)						/* segmented image got allocated?	*/
    DT_I(dtimage_free,(ctl,				/* free it							*/
      &segmented));

  return rc;
}

/*..........................................................................*/

dt_rc_e
dtlev85_cmd_output(						/* import images and do uniformity	*/
  dtparam_t *param,
  char *gray_name,
  char *segmented_name,
  char *output_name,
  dtxy_t xpos,
  dtxy_t ypos)
{
  DT_F("dtlev85_cmd_output");
  dt_ctl_t *ctl = &param->ctl;
  dtimage_t segmented, gray;			/* image structures					*/
  dtimage_t output;
  out_arg_t callback_arg;
  dtxy_t xmax, ymax;
  dthist_t hist;
  dt_rc_e rc;

  gray.xe = 0;
  segmented.xe = 0;
  output.xe = 0;
  hist.freq = NULL;

  DT_C(dtimage_import,(ctl,				/* get gray image					*/
    &gray, gray_name));

  rc = dtimage_check_1f(ctl,			/* check simple stuff				*/
    &gray, "gray",
    DTLEV85_GRAY_NTYPE_LIST,			/* gray ntypes are constrained		*/
    DTIMAGE_FLAG_PAGED, F);
  if (rc != DT_RC_GOOD)
    goto cleanup;

  DT_C(dtimage_import,(ctl,				/* get segmented image				*/
    &segmented, segmented_name));

  xmax = DT_MIN(gray.xe,				/* use minimum image size 			*/
    segmented.xe);
  ymax = DT_MIN(gray.ye,
    segmented.ye);

  DT_C(dtimage_create,(ctl,				/* space for output image			*/
    &output, xmax, ymax,
    DT_NTYPE_F1));

  DT_C(dtimage_constant,(ctl,			/* clear output image 				*/
    &output, OUT_BACKGROUND));

  DT_C(dtimage_hist_alloc,(ctl, &gray,	/* get space for the histogram	    */
    &hist));

  DT_C(dtlev85_init,(param,				/* prepare for uniformity computing */
    &callback_arg.lev85, 1, 
    &gray, &hist));

  callback_arg.output = &output;		/* point to image we will output 	*/
  DT_C(dtimage_adj,(ctl,				/* use callback on each blob		*/
    &segmented,
    0, 0, xmax, ymax,
    param->background,					/* background is invisible			*/
    dtlev85_cmd_out_callback,
    &callback_arg));

  DT_C(dtimage_export,(ctl,				/* output resulting image 			*/
    &output, output_name, xpos, ypos));
  
cleanup:
  if (hist.freq != NULL)
    DT_I(dthist_free,(ctl, &hist));		/* free space for the histogram   	*/

  if (output.xe)						/* output image got allocated?	    */
  DT_I(dtimage_free,(ctl,				/* free it						    */
    &output));

  if (segmented.xe)						/* segmented image got allocated?	*/
  DT_I(dtimage_free,(ctl,				/* free it							*/
    &segmented));

  if (gray.xe)							/* gray image got allocated?	    */
  DT_I(dtimage_free,(ctl,				/* free it						    */
    &gray));

  return rc;
}

/*..........................................................................*/

dt_rc_e 
dtlev85_cmd_check(						/* check params for this program	*/
  dt_ctl_t *ctl,
  dtparam_t *param,
  dt_interactive_arg_t *arg,
  char *msg,
  char **start)
{
  DT_F("dtlev85_cmd_check");
  int op;
  int i;

  DT_Q(dtstr_choice,(ctl, ops,			/* make sure op is understood	    */
    param->op, &op));

  if (op == -1)
  {
    sprintf(msg,
      "Sorry, op \"%s\" is not understood", 
      param->op);
    *start = param->op_desc;			/* put cursor at this field		    */
    return DT_RC_GOOD;
  }

  if (op < -1)
  {
    sprintf(msg,
      "Sorry, op \"%s\" is ambiguous",
      param->op);
    *start = param->op_desc;			/* put cursor at this field		    */
    return DT_RC_GOOD;
  }

  if (strcmp(param->op, OP_TEST) &&		/* test and time have no args	    */
      strcmp(param->op, OP_TIME))
  for (i=0; i<2; i++)					/* check first two args for a value	*/
  {
    int l = strlen(arg[i].val);
    int j;

    for (j=0; j<l; j++)					/* search value for non-blank	    */
      if (arg[i].val[j] != ' ')
        break;
    if (j == l)
    {
      sprintf(msg, 
        "Please enter something for \"%s\"",
        arg[i].desc);
      *start = arg[i].val;				/* position cursor on this field    */
      return DT_RC_GOOD;
    }
  }

  return DT_RC_GOOD;
}

/*..........................................................................*/

dt_rc_e 
dtlev85_cmd_label_callback(
  dt_ctl_t *ctl,
  void *callback_arg,
  double label,
  dtlev85_t *lev85)
{
  label_arg_t * label_arg =
    (label_arg_t *)callback_arg;
  label_arg->n++;						/* keep count of labels encountered */
  printf(
    "  label %3ld uniformity %0.5f,"
    " regions %4ld\n",
	(long)label,
    lev85->u,
    lev85->n);
  return DT_RC_GOOD;
}
	
/*..........................................................................
| Called for each pixel-rectangle by dtimage_adj.
| This function should illustrate how to compute uniformity.
| If you are already doing some kind of blob computation,
| simply merge the code below into your existing callback routine.
| Building the total uniformity is for example only.
 *..........................................................................*/

dt_rc_e
dtlev85_cmd_blob_callback(
  dt_ctl_t *ctl,
  dtimage_adj_callback_arg_t *arg,
  dtxy_t x1,
  dtxy_t y1,
  dtxy_t x2,
  dtxy_t y2)
{
  DT_F("dtlev85_blob_callback");
  blob_arg_t *blob_arg =
    (blob_arg_t *)arg->arg;
  int flag = arg->flag;

  arg->flag = 0;						/* clear flag for next blob		    */

  if (flag & DTIMAGE_ADJ_FLAG_END)		/* finishing an old blob?			*/
  {
	DT_Q(dtlev85_contribute,(			/* contribute to blob's uniformity	*/
      blob_arg->this_lev85.param, 
      &blob_arg->this_lev85));
	if (blob_arg->this_lev85.Aa)		/* blob was big enough? 			*/
	{
  	  DT_Q(dtlev85_compute,(			/* compute blob's uniformity		*/
        blob_arg->this_lev85.param, 
        &blob_arg->this_lev85));
      printf(							/* print out blob's uniformity 		*/
        "  blob %4d: label %3d"
        " area %6ld, fmin %3d, fmax %3d,"
        " uniformity %7.5f\n",
	    blob_arg->n++, 
        blob_arg->v,
        blob_arg->this_lev85.Aa,
        (int)blob_arg->this_lev85.fmin,
        (int)blob_arg->this_lev85.fmax,
        blob_arg->this_lev85.u);
  	  DT_Q(dtlev85_combine,(			/* contribute this one-blob region	*/
        blob_arg->this_lev85.param,		/*   to total uniformity we are 	*/
        &blob_arg->this_lev85,			/*   building 						*/
        &blob_arg->total_lev85,
        &blob_arg->total_lev85));
	}

    if (!(flag & DTIMAGE_ADJ_FLAG_BEG))	/* not also starting a new blob?	*/
      return DT_RC_GOOD;
  }

  if (flag & DTIMAGE_ADJ_FLAG_BEG)		/* starting a new blob?				*/
  {
	blob_arg->v =						/* label value of this blob 		*/
      arg->image->row[y1].b08[x1];
    DT_Q(dtlev85_init,(					/* init accumulation structure		*/
      blob_arg->total_lev85.param,
      &blob_arg->this_lev85, 1,
      blob_arg->total_lev85.gray,
      blob_arg->total_lev85.hist));
    DT_Q(dthist_clear,(ctl,				/* clear histogram					*/
      blob_arg->total_lev85.hist));
  }

  {
	int x, y;
    dthist_freq_t * const h =			/* for short and fast 				*/
      blob_arg->this_lev85.hist->freq;
    for (y=y1; y<=y2; y++)
    {
      const dt_ntype_b08_t * const p =	/* coursing pointer on gray row 	*/
        blob_arg->this_lev85.gray->
          row[y].b08;
      for (x=x1; x<=x2; x++)
	    h[p[x]]++;						/* histogram contribution			*/
    }
  }
    
  return DT_RC_GOOD;					/* keep doing blobs				    */
}
	
/*..........................................................................
 *..........................................................................*/

dt_rc_e
dtlev85_cmd_out_callback(
  dt_ctl_t *ctl,
  dtimage_adj_callback_arg_t *arg,
  dtxy_t x1,
  dtxy_t y1,
  dtxy_t x2,
  dtxy_t y2)
{
  DT_F("dtlev85_out_callback");
  out_arg_t *out_arg =
    (out_arg_t *)arg->arg;
  int flag = arg->flag;

  arg->flag = 0;						/* clear flag for next blob		    */

  if (flag & DTIMAGE_ADJ_FLAG_END)		/* finishing an old blob?			*/
  {
	DT_Q(dtlev85_contribute,(			/* contribute to blob's uniformity	*/
      out_arg->lev85.param,				
      &out_arg->lev85));
	DT_Q(dtlev85_compute,(				/* compute blob's uniformity		*/
      out_arg->lev85.param, 
      &out_arg->lev85));
    DT_Q(dtimage_adj_one,(ctl,			/* replace blob's pixels with		*/
      out_arg->output,					/* uniformity in output				*/
      out_arg->xseed,
      out_arg->yseed,
      out_arg->lev85.u,
      NULL, NULL));

    if (!(flag & DTIMAGE_ADJ_FLAG_BEG))	/* not also starting a new blob?	*/
      return DT_RC_GOOD;
  }

  if (flag & DTIMAGE_ADJ_FLAG_BEG)		/* starting a new blob?				*/
  {
	out_arg->xseed = x1;				/* remember the seed location 		*/
	out_arg->yseed = y1;
    DT_Q(dtlev85_init,(					/* init accumulation structure		*/
      out_arg->lev85.param,
      &out_arg->lev85, 1,
      out_arg->lev85.gray,
      out_arg->lev85.hist));
    DT_Q(dthist_clear,(ctl,				/* clear histogram					*/
      out_arg->lev85.hist));
  }

  {
	int x, y;
    dthist_freq_t * const h =			/* for short and fast 				*/
      out_arg->lev85.hist->freq;
    for (y=y1; y<=y2; y++)
    {
      const dt_ntype_b08_t * const p =	/* coursing pointer on gray row 	*/
        out_arg->lev85.gray->
          row[y].b08;
      for (x=x1; x<=x2; x++)
	    h[p[x]]++;						/* histogram contribution			*/
      DTIMAGE_SET_PIXELS(DT_Q, ctl,		/* mark blob pixels in output 		*/
        out_arg->output, x1, x2+1, y,
        OUT_BUILDING);
    }
  }
    
  return DT_RC_GOOD;					/* keep doing blobs				    */
}
	

#ifdef NONO
/*..........................................................................
 *..........................................................................*/

dt_rc_e
dtlev85_cmd_extent_callback(
  dt_ctl_t *ctl,
  dtimage_adj_callback_arg_t *arg,
  dtxy_t x1,
  dtxy_t y1,
  dtxy_t x2,
  dtxy_t y2)
{
  DT_F("dtlev85_extent_callback");
  out_arg_t *out_arg =
    (out_arg_t *)arg->arg;
  int flag = arg->flag;
  dtxy_t x, y;

  arg->flag = 0;						/* clear flag for next blob		    */

  if (flag & DTIMAGE_ADJ_FLAG_END)		/* finishing an old blob?			*/
  {
    if (!(flag & DTIMAGE_ADJ_FLAG_BEG))	/* not also starting a new blob?	*/
      return DT_RC_GOOD;
  }

  if (flag & DTIMAGE_ADJ_FLAG_BEG)		/* starting a new blob?				*/
  {
	out_arg->xmin = out_arg->xmax = x1;
	out_arg->ymin = out_arg->ymax = y1;
  }

  if (y1 == 0 || y1 == 1 || y1 == 128 || y1 == 129)
	dt_dbg(ctl, F, DT_DBG_MASK_ASSERT,
	  "y1 %u, x1 %u, x2 %u", y1, x1, x2); 
  
  for (y=y1; y<=y2; y++)
    for (x=x1; x<=x2; x++)
	{
	  out_arg->xmin = DT_MIN(out_arg->xmin, x);
	  out_arg->xmax = DT_MAX(out_arg->xmax, x);
	  out_arg->ymin = DT_MIN(out_arg->ymin, y);
	  out_arg->ymax = DT_MAX(out_arg->ymax, y);
	}
    
  return DT_RC_GOOD;					/* keep doing blobs				    */
}

#endif
