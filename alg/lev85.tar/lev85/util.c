#include <dt.h>
DT_RCSID("alg/lev85 $RCSfile: util.c,v $ $Revision: 1.9 $");
#include <dtlev85.h>

/*..........................................................................
| NAME
| dtlev85_init() - initialize structure
| 
| DESCRIPTION
| dtlev85_init() initializes one or more dtlev85 structures
| in preparation for accumulating regions into them.
|_index dtlev85 structure,, initialization
|_index initialization,, of dtlev85 structure
|
| Each of the ~lev85~ structures in the array of length ~n~ is initialized.
| Values of pixels in the ~gray~ image will be used by 
| dtlev85_contribute() when building the histogram ~hist~.
| 
| Initializing a dtlev85 structure means that the next call to
| dtlev85_contribute() will be adding the first region to it.
|
| The ~hist~ argument may be NULL if you have a custom routine
| which assigns ~lev85->hist~ to point to a suitable histogram
| before calling dtlev85_contribute().
|
| Each structure in the array is assigned the same histogram.
| This is because a histogram consumes a non-negligible amount of memory.
| It would be wasteful for each dtlev85 structure to have is own
| histogram since the logic of the code may often be arranged
| such that only one histogram at a time is needed.
| 
| This function allocates no resources.
| There is no corresponding dtlev85_uninit() function.
| 
| PARAMETERS
|dtinclude(ctlonly.dx)
| 
| CAVEATS
| Attempting to use a dtlev85 structure without first initializing it
| may result in incorrect results.
|
| EXAMPLE
| Please refer to the example for the dtlev85_compute() function.
|
| RETURN VALUES
| The contents of all dtlev85 structures in the ~lev85~ array are cleared.
| Certain members are also given initial values.
|dtinclude(return1.dx)
| 
| ERRORS
| Unsuccessful completion may be due to:
| - ~gray~ image does not have a valid data type
| - ~n~ less than or equal to 0
| 
| SEE ALSO
| dtlev85_contribute()		contributes a region to the area
| dtlev85_compute()			computes uniformity for the area
| dtlev85_combine()			combines two areas into a single area
|
| END
 *..........................................................................*/

dt_rc_e
dtlev85_init(							/* init structure					*/
  dtparam_t *param,						/* control parameter structure 		*/
  dtlev85_t *lev85,						/* array of structures to init 		*/
  unsigned int n,						/* number of structures to init 	*/
  const dtimage_t *gray,				/* original gray low level 			*/
  dthist_t *hist)						/* histogram structure to be used 	*/
{
  DT_F("dtlev85_init");
  dt_ctl_t *ctl = param? 
    &param->ctl: NULL;
  int i;
  double fmin;
  double fmax;
  dt_rc_e rc;
  rc = dtimage_check_1f(ctl,			/* check simple stuff				*/
    gray, NULL, 
    DTLEV85_GRAY_NTYPE_LIST,			/* gray ntypes are constrained		*/
    DTIMAGE_FLAG_PAGED, F);
  if (rc != DT_RC_GOOD)
    return rc;
  if (n <= 0)
    return dt_err(ctl, F,
      "invalid valud %d for argument n",
      n);
  fmin = dt_ntype_minval[gray->ntype];
  fmax = dt_ntype_maxval[gray->ntype];
  for (i=0; i<n; i++)
  {
	memset(lev85, 0, sizeof(*lev85));
  	lev85->hist = hist;
  	lev85->gray = gray;
	lev85->fmin = fmax;					/* reverse these as initial values 	*/
	lev85->fmax = fmin;
	lev85->param = param;
	lev85++;
  } 
  return DT_RC_GOOD;
}

/*..........................................................................
| NAME
| dtlev85_combine() - combine uniformity of two areas
| 
| DESCRIPTION
| dtlev85_combine() combines the structures describing the uniformity
| of two areas into a single area.
|_index dtlev85 structures,, combining
|_index combine,, two dtlev85 structures
|_index areas,, combine two
|
| The ~a2~ structure is changed such that it represents
| the accumulation of all regions which have contributed to
| both ~a0~ and ~a1~.
| 
| ~a2~ may point to the same structure as either ~a1~ or ~a0~.
| This function does not require that the ~a2~ structure has been 
| initialized by dtlev85_init().
| However, if it is subsequently to be used in a call to
| dtlev85_contribute(), then initialization is necessary.
| 
| This function is very cheap compared to a full connectivity
| analysis on a segmented image.
| 
| In a dynamic environment, the set of regions composing an area
| will be continually changing.
| The well-known split/merge technique is such an environment.
| This function is designed to be used in a dynamic environment.
| Consider the naive case in which each area consists of a single region.
| As part of the region-finding process, the intrinsic uniformity
| of each region is accumulated.
| This expensive process need not be repeated, even as the regions 
| are merged in various ways in the search for the "best" segmentation.
| Instead, the much cheaper dtlev85_combine() is used.
| 
| The following steps outline a possible approach:
| 1.	initialize a set of lev85 structures,
|		one for each region (dtlev85_init())
| 2.	for each region, compute the histogram
|		and call dtlev85_contribute(),
|		giving the lev85 structure associated with that region
| 3.	merge regions into areas as desired,
|		calling dtlev85_combine() for each region in the area
| 4.	call dtlev85_compute() to compute the uniformity of the area
| 5.	repeat steps 3 and 4 until the desired segmentation goodness
|		criteria have been mapped
| 
| After step 2, there is no need for further expensive connectivity analysis
| unless the regions themselves change.
| 
| PARAMETERS
|dtinclude(ctlonly.dx)
|
| EXAMPLE
|:  dtlev85_t lev[4];
|:  ...
|:  dtlev85_init(NULL, lev, 4,			// initialize four lev85 structures
|:    &gray, &hist);
|:  ... compute first histogram
|:  dtlev85_contribute(NULL, &lev[1]);	// first region
|:  ... compute second histogram
|:  dtlev85_contribute(NULL,  &lev[2]);	// second region
|:  ... compute third histogram
|:  dtlev85_contribute(NULL, &lev[3]);	// third region
|:  dtlev85_combine(&lev[1], &lev[2],	// combine first two regions
|:    &lev[0]);
|:  dtlev85_combine(&lev[0], &lev[3],	// combine third region
|:    &lev[0]);
|:  dtlev85_compute(NULL, &lev[0]);		// compute final uniformity
|:  printf("uniformity %e\n",			// print the uniformity
|:    lev[0].u);	
|
| RETURN VALUES
| The contents of ~a2~ structure are set to reflect
| the combined contribution of the other two areas.
|dtinclude(return1.dx)
| 
| ERRORS
|dtinclude(noerror.dx)
| 
| SEE ALSO
| dtlev85_init()			contributes a region to the area
| dtlev85_contribute()		contributes a region to the area
| dtlev85_compute()			computes uniformity for the area
|
| END
 *..........................................................................*/

dt_rc_e
dtlev85_combine(						/* combine uniformity of two areas	*/
  dtparam_t *param,						/* control parameter structure 		*/
  dtlev85_t *a0,						/* first area 						*/
  dtlev85_t *a1,						/* second area 						*/
  dtlev85_t *a2)						/* output combined area 			*/
{
  a2->Aa = a0->Aa + a1->Aa;
  a2->Ua = a0->Ua + a1->Ua;
  a2->n  = a0->n  + a1->n;
  a2->fmin = DT_MIN(a0->fmin, a1->fmin);
  a2->fmax = DT_MAX(a0->fmax, a1->fmax);
  return DT_RC_GOOD;
}

/*..........................................................................
| NAME
| dtlev85_contribute() - contribute region to uniformity
| 
| DESCRIPTION
| dtlev85_contribute() accumulates one region's contribution into
| the uniformity structure.
|_index dtlev85 structure,, contribution of a region to
|_index contribution,, of a region to dtlev85 structure
|_index region,, contribution to a dtlev85 structure
|
| The ~lev85~ structure is upgraded to include the uniformity
| of the region described by the histogram ~lev85->hist~.
| The uniformity itself is not computed by this function.
| Instead it is deferred until dtlev85_compute() is called.
| 
| For the purposes of this function, the region to be contributed
| is completely described by its histogram ~lev85->hist~.
| This histogram may have been computed in any manner desired.
| For example, the functions dtlev85_label() and dtlev85_total()
| extract regions from a segmented image using connectivity analysis.
| Histograms for the individual regions are computed during extraction.
| Once extraction of a region is completed, dtlev85_contribute() is called.
|
| This function is designed to be called multiple times before
| an actual uniformity is computed.
| The steps to computing the uniformity of a multiple-region area are:
| 1.	initialize structure (dtlev85_init())
| 2.	compute histogram of first region
| 3.	accumulate region's contribution (dtlev85_contribute())
| 4.	compute histogram of next region
| 5.	accumulate region's contribution (dtlev85_contribute())
| 6.	repeat steps 4 and 5 for each remaining region
| 7.	compute final uniformity (dtlev85_compute())
| 
| PARAMETERS
|dtinclude(ctlonly.dx)
| 
| CAVEATS
| Attempting to use a dtlev85 structure without first initializing it
| may result in incorrect results.
|
| EXAMPLE
| Please refer to the example for the dtlev85_compute() function.
|
| RETURN VALUES
| The contents of the dtlev85 structure are updated to include
| the contribution of the region.
|dtinclude(return1.dx)
| 
| ERRORS
| Unsuccessful completion may be due to:
| - ~lev85->hist~ is not a valid histogram type
| 
| SEE ALSO
| dtlev85_init()			contributes a region to the area
| dtlev85_compute()			computes uniformity for the area
| dtlev85_combine()			combines two areas into a single area
|
| END
 *..........................................................................*/

dt_rc_e
dtlev85_contribute(						/* contribute region to uniformity	*/
  dtparam_t *param,						/* control parameter structure 		*/
  dtlev85_t *lev85)
{
  static char *F = "dtlev85_contribute";
  dt_ctl_t *ctl = param? &param->ctl: NULL;
  long Aj, sum;
  unsigned int g;
  double fbar, varj;
  const dthist_bin_t w =
    lev85->hist->width;
  const dthist_freq_t * const h =
    lev85->hist->freq;

  sum = 0;
  Aj = 0;
  for (g=0; g<w; g++)
  if (h[g] != 0)
  {
    Aj += h[g];							/* area of region				    */
    sum += h[g] * g;					/* sum of gray levels in region		*/
  }

  if (lev85->param &&
      Aj < (long)lev85->param->min)		/* region too small?			    */
    return DT_RC_GOOD;

  for (g=0; g<256; g++)					/* scan for region min gray level   */
    if (h[g]) break;
  lev85->fmin = DT_MIN(lev85->fmin, g);	/* feature min						*/

  for (g=255; g>1; g--)					/* scan for region max gray level   */
    if (h[g]) break;
  lev85->fmax = DT_MAX(lev85->fmax, g);

  fbar = (double)sum / (double)Aj;		/* mean of gray levels in region	*/

  varj = 0.0;
  for (g=0; g<256; g++)
    varj += (double)h[g] *				/* gray contributes to variance		*/
      ((double)g-fbar) *
      ((double)g-fbar);

  dt_dbg(ctl, F, DT_DBG_MASK_OBJECT,
    "Aj %6ld, fbar %5.1f, varj %8.2e",
    Aj, fbar, varj/Aj);

  lev85->n++;							/* keep count of regions		    */
  lev85->Aa += Aj;						/* keep sum of total area		    */
  lev85->Ua += varj;					/* region contributes to uniformity	*/
										/* Aj in variance denominator of	*/
										/*   eqn (2) p.158 is cancelled by 	*/
										/*   Aj weight in eqn (9). 			*/
  return DT_RC_GOOD;
}

/*..........................................................................
| NAME
| dtlev85_compute() - compute final uniformity of area
| 
| DESCRIPTION
| dtlev85_compute() computes the final uniformity of the area.
|_index dtlev85 structure,, computation of uniformity using
|_index uniformity,, final computation of
|
| The given ~lev85~ structure must have been initialized by dtlev85_init().  
| It will normally have had one or more region contributions
| added to it by dtlev85_contribute().
| 
| The computed uniformity is placed in the structure member ~lev85->u~.
| If no regions have contributed to the structure,
| then the uniformity is returned as 0.0.
|
| This function effectively implements equations (7) and (8) of [lev85].
| The summation term has already been done as part of the accumulation.
|
| The ~lev85->hist~ member of the structure is not referenced
| by this function.
| 
| PARAMETERS
|dtinclude(ctlonly.dx)
| 
| CAVEATS
| Attempting to use a dtlev85 structure without first initializing it
| may result in incorrect results.
| 
| Computing the uniformity of an area with no contributed regions will
| result in a value of 0.
|
| EXAMPLE lev85c.c
|:// example program dtlev85c
|:// illustrate dtlev85_init(), dtlev85_contribute(), and dtlev85_compute()
|:// single argument is the gray level image filename, such as:
|://     dtlev85c data/dice64.pgm
|:// uniformity of image taken as monolithic region is computed and printed
|:// all error checking left out for clarity
|:#include <dt.h>
|:#include <dtlev85.h>
|:void main(int argc, char *argv[])
|:{
|:  dtimage_t seg;
|:  dtimage_t gray;
|:  dthist_t hist;
|:  dtlev85_t lev85;
|:  dtimage_import(NULL,		 		// read and allocate gray image
|:    &gray, argc>1? argv[1]: "");
|:  dtimage_create(NULL, &seg,			// create space for segmented image
|:    gray.xe, gray.ye, DT_NTYPE_B08);	// same size as gray image
|:  dtimage_constant(NULL, &seg, 1);	// make one giant blob of 1's
|:  dtimage_hist_alloc(NULL, &gray,		// space for histogram
|:    &hist);
|:  dtimage_hist(NULL, &gray,			// get histogram of gray image
|:    &hist);
|:  dtlev85_init(NULL, &lev85, 1,		// initialize lev85 structure
|:    &gray, &hist);
|:  dtlev85_contribute(NULL, &lev85);	// contribute giant blob
|:  dtlev85_compute(NULL, &lev85);		// compute final uniformity
|:  printf("uniformity %e\n",			// print the uniformity
|:    lev85.u);
|:}
|
| RETURN VALUES
| The ~lev85->u~ structure member is assigned the area's uniformity.
|dtinclude(return1.dx)
| 
| ERRORS
| Unsuccessful completion may be due to:
| - ~gray~ image does not have a valid data type
| - ~n~ less than or equal to 0
| 
| SEE ALSO
| dtlev85_contribute()		contributes a region to the area
| dtlev85_compute()			computes uniformity for the area
| dtlev85_combine()			combines two areas into a single area
|
| END
 *..........................................................................*/

dt_rc_e
dtlev85_compute(						/* compute final uniformity of area	*/
  dtparam_t *param,						/* control parameter structure 		*/
  dtlev85_t *lev85)						/* structure of accumulated regions */
{
  DT_F("dtlev85_compute");
  dt_ctl_t *ctl = param? 
    &param->ctl: NULL;

  if (lev85->n > 0)						/* got some regions?			    */
  {
	double fdiff;
	double varjmax;
    fdiff = lev85->fmax - lev85->fmin;
	varjmax = fdiff * fdiff / 2.0;		/* maximum variance					*/

    dt_dbg(ctl, F, DT_DBG_MASK_INTERMD,
      "Ua %8.2e, Aa %6ld,"
      " fmin %3ld, fmax %3ld,"
      " varjmax %8.2e",
      lev85->Ua, lev85->Aa,
      (long)lev85->fmin, 
      (long)lev85->fmax, 
      varjmax);

    if (varjmax != 0.0)					/* there is some variation?		    */
      lev85->u = 1.0 - lev85->Ua /		/* normalize and unitize			*/
        (double)lev85->Aa / varjmax;
    else								/* no variation among all pixels?	*/
      lev85->u = 1.0;
  }
  else									/* no regions?					    */
    lev85->u = 0.0;

  return DT_RC_GOOD;
}
